#!/usr/bin/env python3
"""
run.py — Ellis & Messina Offline Search entry point.

Usage:
    python run.py                   # auto-build DB if needed, open browser
    python run.py --rebuild         # force full database rebuild first
    python run.py --no-browser      # start server without opening browser
    python run.py --port 5050       # use a specific port (default: 5050)
    python run.py --host 0.0.0.0   # listen on all interfaces (LAN access)
"""

import argparse
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.resolve()
DB_PATH = PROJECT_ROOT / "em_database.db"


# ------------------------------------------------------------------
# Utilities
# ------------------------------------------------------------------

def find_free_port(preferred: int = 5050) -> int:
    """Try preferred port, then nearby ports, then let OS pick."""
    for port in [preferred, preferred + 1, preferred + 2, 8080, 8888, 9090]:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    # Last resort: OS-assigned
    with socket.socket() as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def open_browser_delayed(url: str, delay: float = 1.8):
    """Open browser after a short delay to let Flask fully start."""
    def _open():
        time.sleep(delay)
        webbrowser.open(url)
    t = threading.Thread(target=_open, daemon=True)
    t.start()


def check_metadata_exists() -> list[str]:
    """Return list of missing metadata JSON files."""
    from build_database import DATABASE_FILES
    missing = []
    for db_name, path in DATABASE_FILES.items():
        if not path.exists():
            missing.append(f"  {db_name}: {path}")
    return missing


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Ellis & Messina Offline Search",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run.py                  # Quick start
  python run.py --rebuild        # Force DB rebuild then start
  python run.py --no-browser     # Start server only (no browser)
  python run.py --port 8080      # Use port 8080
        """,
    )
    parser.add_argument("--port", type=int, default=5050,
                        help="Port to run on (default: 5050)")
    parser.add_argument("--host", default="127.0.0.1",
                        help="Host to bind to (default: 127.0.0.1 — localhost only)")
    parser.add_argument("--rebuild", action="store_true",
                        help="Force full SQLite database rebuild from JSON files")
    parser.add_argument("--no-browser", action="store_true",
                        help="Do not auto-open browser")
    args = parser.parse_args()

    print()
    print("=" * 55)
    print("  Ellis & Messina Micropaleontology — Offline Search")
    print("=" * 55)
    print()

    # ------------------------------------------------------------------
    # Step 1: Check JSON metadata exists
    # ------------------------------------------------------------------
    missing = check_metadata_exists()
    if missing:
        print("WARNING: Some metadata JSON files not found:")
        for m in missing:
            print(m)
        print("  (Only available databases will be indexed)")
        print()

    # ------------------------------------------------------------------
    # Step 2: Build or validate database
    # ------------------------------------------------------------------
    from build_database import build, check_needs_rebuild

    needs_build = args.rebuild or not DB_PATH.exists() or check_needs_rebuild()

    if needs_build:
        if args.rebuild:
            print("Forcing full database rebuild (--rebuild flag)...")
        elif not DB_PATH.exists():
            print("Database not found — building from JSON metadata...")
        else:
            print("JSON files have changed — rebuilding database...")
        print()

        result = build(force=args.rebuild, verbose=True)
        if result["built"]:
            print()
            print(f"Database ready: {result['total']:,} records "
                  f"in {result['elapsed']:.1f}s")
        else:
            print(f"Database is current: {result['total']:,} records")
    else:
        try:
            import sqlite3
            conn = sqlite3.connect(str(DB_PATH))
            row = conn.execute(
                "SELECT value FROM db_meta WHERE key = 'total_count'"
            ).fetchone()
            conn.close()
            count = int(row[0]) if row else 0
            print(f"Database found: {count:,} records in {DB_PATH.name}")
        except Exception as e:
            print(f"Warning: could not read DB stats: {e}")

    # ------------------------------------------------------------------
    # Step 3: Validate database is readable
    # ------------------------------------------------------------------
    try:
        import sqlite3
        conn = sqlite3.connect(str(DB_PATH))
        conn.execute("SELECT COUNT(*) FROM records").fetchone()
        conn.close()
    except Exception as e:
        print(f"\nERROR: Database validation failed: {e}", file=sys.stderr)
        print("Try running:  python build_database.py --force", file=sys.stderr)
        sys.exit(1)

    # ------------------------------------------------------------------
    # Step 4: Find port and start server
    # ------------------------------------------------------------------
    port = find_free_port(args.port)
    if port != args.port:
        print(f"\nNote: port {args.port} is in use, using {port} instead")

    url = f"http://{args.host if args.host != '0.0.0.0' else '127.0.0.1'}:{port}/"

    print()
    print(f"Starting server at  {url}")
    print(f"Press Ctrl+C to stop")
    print()

    if not args.no_browser:
        open_browser_delayed(url, delay=1.8)

    from app import app as flask_app
    flask_app.run(
        host=args.host,
        port=port,
        debug=False,
        use_reloader=False,   # no reloader for single-user tool
        threaded=True,        # allow concurrent requests (PDF + search)
    )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nServer stopped.")
