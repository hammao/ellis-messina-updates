"""
search.py — Search logic for the Ellis & Messina offline database.

Primary path:  FTS5 prefix search   (<1 ms for 83K records)
Fuzzy path:    rapidfuzz WRatio      (~100 ms, only when explicitly requested)
Browse path:   pure SQL filter       (<1 ms, no text query)
"""

import re
import sqlite3
import time
from pathlib import Path
from typing import Optional

try:
    from rapidfuzz import fuzz, process as fuzz_process
    _RAPIDFUZZ_AVAILABLE = True
except ImportError:
    _RAPIDFUZZ_AVAILABLE = False

import sys as _sys
if getattr(_sys, "frozen", False):
    PROJECT_ROOT = Path(_sys.executable).parent.resolve()
else:
    PROJECT_ROOT = Path(__file__).parent.resolve()
DB_PATH = PROJECT_ROOT / "em_database.db"

# Module-level read-only connection (single-user tool)
_conn: Optional[sqlite3.Connection] = None

# Fuzzy index (loaded lazily on first fuzzy request)
_fuzzy_names: Optional[list[str]] = None
_fuzzy_ids: Optional[list[int]] = None


def get_db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        if not DB_PATH.exists():
            raise FileNotFoundError(
                f"Database not found at {DB_PATH}. "
                "Run: python build_database.py"
            )
        _conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA query_only = ON")
    return _conn


def close_db():
    global _conn
    if _conn is not None:
        _conn.close()
        _conn = None


# ------------------------------------------------------------------
# FTS5 query sanitizer
# ------------------------------------------------------------------

_FTS_SPECIAL = re.compile(r'["*^(){}\[\]|:]')


def _build_fts_query(user_input: str) -> Optional[str]:
    """
    Convert raw user text into a safe FTS5 MATCH expression.

    Rules:
    - Strip FTS5 operators that cause syntax errors
    - Append '*' to the last token for prefix matching
    - Return None if no usable terms remain

    Examples:
      'Triloculina'        -> 'Triloculina*'
      'Triloculina plic'   -> 'Triloculina plic*'
      '"glob.gerina"'      -> 'glob.gerina*'
    """
    cleaned = _FTS_SPECIAL.sub(" ", user_input)
    terms = cleaned.split()
    if not terms:
        return None
    # Prefix-match the last term; earlier terms must match exactly
    return " ".join(terms[:-1] + [terms[-1] + "*"])


# ------------------------------------------------------------------
# Fuzzy index (lazy load)
# ------------------------------------------------------------------

def _load_fuzzy_index():
    global _fuzzy_names, _fuzzy_ids
    conn = get_db()
    # Temporarily lift query_only for this fetch (it's a SELECT, safe)
    rows = conn.execute("SELECT id, taxon_name FROM records ORDER BY id").fetchall()
    _fuzzy_ids = [r[0] for r in rows]
    _fuzzy_names = [r[1] for r in rows]


def _fuzzy_search(query: str) -> list[int]:
    """Return a list of record IDs sorted by fuzzy match score (best first)."""
    if not _RAPIDFUZZ_AVAILABLE:
        return []

    global _fuzzy_names, _fuzzy_ids
    if _fuzzy_names is None:
        _load_fuzzy_index()

    matches = fuzz_process.extract(
        query,
        _fuzzy_names,
        scorer=fuzz.WRatio,
        score_cutoff=70,
        limit=300,
    )
    # matches: list of (matched_str, score, index)
    return [_fuzzy_ids[m[2]] for m in matches]


# ------------------------------------------------------------------
# Row → dict helper
# ------------------------------------------------------------------

def _row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    # Add a convenience URL for PDF serving
    if d.get("pdf_downloaded") and d.get("pdf_path"):
        d["pdf_url"] = f"/pdf/{d['record_id']}/{d['database']}"
    else:
        d["pdf_url"] = None
    return d


# ------------------------------------------------------------------
# Main search function
# ------------------------------------------------------------------

def search(
    query: str = "",
    genus: str = "",
    author: str = "",
    year_from: Optional[int] = None,
    year_to: Optional[int] = None,
    database: str = "All",
    pdf_only: bool = False,
    fuzzy: bool = False,
    page: int = 1,
    page_size: int = 50,
) -> dict:
    """
    Search the Ellis & Messina database.

    Returns:
        {
          'results': list[dict],
          'total': int,
          'page': int,
          'pages': int,
          'query_type': 'fts'|'like'|'fuzzy'|'browse',
          'elapsed_ms': float,
        }
    """
    t0 = time.perf_counter()
    conn = get_db()

    query = (query or "").strip()
    genus = (genus or "").strip()
    author = (author or "").strip()

    # Common filter params
    db_filter = database if database != "All" else None
    author_like = f"%{author}%" if author else None
    genus_like = f"%{genus}%" if genus else None
    pdf_flag = 1 if pdf_only else None

    offset = (page - 1) * page_size

    # ------------------------------------------------------------------
    # Path 1: Fuzzy search (explicit opt-in, ~100ms)
    # ------------------------------------------------------------------
    if query and fuzzy:
        if not _RAPIDFUZZ_AVAILABLE:
            return {
                "results": [],
                "total": 0,
                "page": page,
                "pages": 0,
                "query_type": "fuzzy",
                "elapsed_ms": 0.0,
                "error": "rapidfuzz is not installed",
            }

        matched_ids = _fuzzy_search(query)
        if not matched_ids:
            return _empty(page, "fuzzy", t0)

        # Apply filters to matched IDs
        placeholders = ",".join("?" * len(matched_ids))
        filter_clauses, filter_params = _build_filter_clauses(
            db_filter, author_like, genus_like, year_from, year_to, pdf_flag
        )
        where = f"WHERE id IN ({placeholders})"
        if filter_clauses:
            where += " AND " + " AND ".join(filter_clauses)

        total = conn.execute(
            f"SELECT COUNT(*) FROM records {where}",
            matched_ids + filter_params,
        ).fetchone()[0]

        # Preserve fuzzy score order using ORDER BY CASE WHEN
        order_case = " ".join(
            f"WHEN id={rid} THEN {i}" for i, rid in enumerate(matched_ids)
        )
        rows = conn.execute(
            f"SELECT * FROM records {where} "
            f"ORDER BY CASE {order_case} ELSE {len(matched_ids)} END "
            f"LIMIT ? OFFSET ?",
            matched_ids + filter_params + [page_size, offset],
        ).fetchall()

        return _build_response(rows, total, page, page_size, "fuzzy", t0)

    # ------------------------------------------------------------------
    # Path 2: FTS5 search (primary, <1ms)
    # ------------------------------------------------------------------
    if query:
        fts_expr = _build_fts_query(query)

        if fts_expr:
            filter_clauses, filter_params = _build_filter_clauses(
                db_filter, author_like, genus_like, year_from, year_to, pdf_flag
            )
            filter_sql = ""
            if filter_clauses:
                filter_sql = " AND " + " AND ".join(filter_clauses)

            try:
                total = conn.execute(
                    f"""SELECT COUNT(*)
                        FROM records_fts f
                        JOIN records r ON f.rowid = r.id
                        WHERE records_fts MATCH ?{filter_sql}""",
                    [fts_expr] + filter_params,
                ).fetchone()[0]

                rows = conn.execute(
                    f"""SELECT r.*
                        FROM records_fts f
                        JOIN records r ON f.rowid = r.id
                        WHERE records_fts MATCH ?{filter_sql}
                        ORDER BY rank
                        LIMIT ? OFFSET ?""",
                    [fts_expr] + filter_params + [page_size, offset],
                ).fetchall()

                return _build_response(rows, total, page, page_size, "fts", t0)

            except sqlite3.OperationalError:
                # FTS syntax error — fall through to LIKE search
                pass

        # LIKE fallback (very short or special-char query)
        like_pat = f"%{query}%"
        filter_clauses, filter_params = _build_filter_clauses(
            db_filter, author_like, genus_like, year_from, year_to, pdf_flag
        )
        where = "WHERE r.taxon_name LIKE ?"
        if filter_clauses:
            where += " AND " + " AND ".join(filter_clauses)

        total = conn.execute(
            f"SELECT COUNT(*) FROM records r {where}",
            [like_pat] + filter_params,
        ).fetchone()[0]

        rows = conn.execute(
            f"SELECT r.* FROM records r {where} "
            f"ORDER BY r.taxon_name COLLATE NOCASE "
            f"LIMIT ? OFFSET ?",
            [like_pat] + filter_params + [page_size, offset],
        ).fetchall()

        return _build_response(rows, total, page, page_size, "like", t0)

    # ------------------------------------------------------------------
    # Path 3: Browse (no text query — pure filter)
    # ------------------------------------------------------------------
    filter_clauses, filter_params = _build_filter_clauses(
        db_filter, author_like, genus_like, year_from, year_to, pdf_flag
    )
    where = ""
    if filter_clauses:
        where = "WHERE " + " AND ".join(filter_clauses)

    total = conn.execute(
        f"SELECT COUNT(*) FROM records r {where}", filter_params
    ).fetchone()[0]

    rows = conn.execute(
        f"SELECT r.* FROM records r {where} "
        f"ORDER BY r.taxon_name COLLATE NOCASE "
        f"LIMIT ? OFFSET ?",
        filter_params + [page_size, offset],
    ).fetchall()

    return _build_response(rows, total, page, page_size, "browse", t0)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _build_filter_clauses(
    db_filter, author_like, genus_like, year_from, year_to, pdf_flag
) -> tuple[list[str], list]:
    clauses = []
    params = []

    if db_filter:
        clauses.append("r.database = ?")
        params.append(db_filter)
    if author_like:
        clauses.append("r.author LIKE ?")
        params.append(author_like)
    if genus_like:
        clauses.append("r.genus LIKE ?")
        params.append(genus_like)
    if year_from is not None:
        clauses.append("r.year >= ?")
        params.append(year_from)
    if year_to is not None:
        clauses.append("r.year <= ?")
        params.append(year_to)
    if pdf_flag is not None:
        clauses.append("r.pdf_downloaded = ?")
        params.append(pdf_flag)

    return clauses, params


def _build_response(rows, total, page, page_size, query_type, t0) -> dict:
    elapsed = (time.perf_counter() - t0) * 1000
    pages = max(1, (total + page_size - 1) // page_size)
    results = [_row_to_dict(r) for r in rows]

    # Batch-fetch extinction status from worms_cache (one query, no N+1)
    if results:
        names_lower = [r["taxon_name"].lower() for r in results]
        placeholders = ",".join("?" * len(names_lower))
        try:
            ext_rows = get_db().execute(
                f"SELECT taxon_name, is_extinct FROM worms_cache "
                f"WHERE taxon_name IN ({placeholders})",
                names_lower,
            ).fetchall()
            ext_map = {r["taxon_name"]: r["is_extinct"] for r in ext_rows}
            for rec in results:
                val = ext_map.get(rec["taxon_name"].lower())
                # val: 1=extinct, 0=extant, None=not yet looked up
                rec["is_extinct"] = val
        except Exception:
            for rec in results:
                rec["is_extinct"] = None

    return {
        "results": results,
        "total": total,
        "page": page,
        "pages": pages,
        "query_type": query_type,
        "elapsed_ms": round(elapsed, 2),
    }


def _empty(page, query_type, t0) -> dict:
    elapsed = (time.perf_counter() - t0) * 1000
    return {
        "results": [],
        "total": 0,
        "page": page,
        "pages": 0,
        "query_type": query_type,
        "elapsed_ms": round(elapsed, 2),
    }


# ------------------------------------------------------------------
# Autocomplete / suggest
# ------------------------------------------------------------------

def suggest(query: str, limit: int = 10) -> list[str]:
    """Return up to `limit` distinct taxon names matching a prefix query."""
    if not query or len(query) < 2:
        return []
    fts_expr = _build_fts_query(query)
    if not fts_expr:
        return []
    conn = get_db()
    try:
        rows = conn.execute(
            """SELECT DISTINCT r.taxon_name
               FROM records_fts f
               JOIN records r ON f.rowid = r.id
               WHERE records_fts MATCH ?
               ORDER BY rank
               LIMIT ?""",
            (fts_expr, limit),
        ).fetchall()
        return [r[0] for r in rows]
    except sqlite3.OperationalError:
        return []


# ------------------------------------------------------------------
# Stats
# ------------------------------------------------------------------

def get_stats() -> dict:
    """Return build metadata from db_meta + worms_cache count."""
    conn = get_db()
    try:
        # Temporarily lift query_only restriction for cross-table read
        meta = dict(conn.execute("SELECT key, value FROM db_meta").fetchall())
    except Exception:
        meta = {}
    return meta
