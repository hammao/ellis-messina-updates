@echo off
REM =====================================================================
REM  Ellis & Messina Search — Daily Launcher
REM  Double-click this file to start the app.
REM =====================================================================

title Ellis ^& Messina Search

REM ── Must be run from the app root folder ─────────────────────────────
if not exist "run.py" (
    echo ERROR: This script must be placed in the same folder as run.py
    pause
    exit /b 1
)

REM ── Activate virtual environment if it exists ─────────────────────────
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
) else (
    echo NOTE: No virtual environment found. Using system Python.
    echo       Run install.bat first if you encounter errors.
    echo.
)

REM ── Check database ────────────────────────────────────────────────────
if not exist "em_database.db" (
    echo Database not found. Building now...
    python build_database.py
    if errorlevel 1 (
        echo ERROR: Database build failed. Run install.bat first.
        pause
        exit /b 1
    )
)

REM ── Launch ────────────────────────────────────────────────────────────
echo Starting Ellis ^& Messina Search...
echo Your browser will open automatically at http://127.0.0.1:5050
echo.
echo Keep this window open while using the app.
echo Press Ctrl+C or close this window to stop the app.
echo.
python run.py

pause
