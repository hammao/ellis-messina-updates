@echo off
REM =====================================================================
REM  Ellis & Messina — Export to Excel
REM  Double-click this to create Ellis_Messina_Database.xlsx
REM =====================================================================

title Ellis ^& Messina — Excel Export

if not exist "run.py" (
    echo ERROR: Must be run from the app folder.
    pause
    exit /b 1
)

if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
) else (
    echo NOTE: No virtual environment found. Run install.bat first.
    echo       Attempting with system Python...
    echo.
)

echo Exporting to Excel...
echo This will take about 15-30 seconds for 83,000+ records.
echo.
python tools\export_to_excel.py

if errorlevel 1 (
    echo.
    echo ERROR: Export failed.
    echo Make sure install.bat was run successfully first.
) else (
    echo.
    echo Done! Open Ellis_Messina_Database.xlsx to search offline.
    echo.
    echo TIP: In Excel, go to the "Database" sheet and use the
    echo      dropdown arrows on column headers to filter records.
)
echo.
pause
