@echo off
REM =====================================================================
REM  Ellis & Messina Search — Windows Installer
REM  Run this once after copying the app folder to your computer.
REM =====================================================================

echo.
echo =====================================================================
echo   Ellis ^& Messina Micropaleontology Search
echo   Windows Installer
echo =====================================================================
echo.

REM ── Must be run from the app root folder ─────────────────────────────
if not exist "run.py" (
    echo ERROR: This script must be placed in the same folder as run.py
    echo.
    echo Current folder: %CD%
    echo Please navigate to the app folder and try again.
    pause
    exit /b 1
)

REM ── Check Python ──────────────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not on your PATH.
    echo.
    echo Please install Python 3.9 or later from:
    echo   https://www.python.org/downloads/
    echo.
    echo IMPORTANT: During installation, check the box:
    echo   "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

echo Python found:
python --version
echo.

REM ── Create virtual environment ────────────────────────────────────────
if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo ERROR: Could not create virtual environment.
        pause
        exit /b 1
    )
    echo Done.
    echo.
)

REM ── Install packages ──────────────────────────────────────────────────
echo Installing required packages...
echo (This may take 1-2 minutes on first run)
echo.
call venv\Scripts\activate.bat
pip install --quiet flask requests rapidfuzz openpyxl
if errorlevel 1 (
    echo ERROR: Package installation failed.
    echo Check your internet connection and try again.
    pause
    exit /b 1
)
echo Packages installed successfully.
echo.

REM ── Build database ────────────────────────────────────────────────────
if exist "em_database.db" (
    echo Search database found — skipping build.
) else (
    if not exist "downloads\metadata\foraminifera_metadata.json" (
        echo.
        echo WARNING: Metadata files not found in downloads\metadata\
        echo.
        echo The app needs the three JSON metadata files:
        echo   downloads\metadata\foraminifera_metadata.json
        echo   downloads\metadata\ostracoda_metadata.json
        echo   downloads\metadata\diatoms_metadata.json
        echo.
        echo Please copy these files from the original data source,
        echo then run install.bat again to build the database.
        echo.
        echo The app will still start but search will not work without the database.
        pause
        goto :done
    )
    echo Building search database from metadata files...
    echo This takes about 5 seconds...
    python build_database.py
    if errorlevel 1 (
        echo ERROR: Database build failed.
        echo Check that downloads\metadata\ contains the JSON files.
        pause
        exit /b 1
    )
    echo Database built successfully.
)
echo.

REM ── PDF location setup ────────────────────────────────────────────
echo.
echo =====================================================================
echo   PDF PLATE SCANS SETUP
echo =====================================================================
echo.
echo The PDF plate scans (35 GB) are NOT included in this package.
echo.
if exist "downloads\Foraminifera" (
    echo PDF folder found: downloads\Foraminifera\ — PDFs should work.
) else (
    echo To enable PDF viewing, choose one of these options:
    echo.
    echo   OPTION A: Copy your downloads\ folder here
    echo     Copy the  downloads\  folder into:  %CD%\
    echo.
    echo   OPTION B: PDFs on a USB drive or another location
    echo     Edit the file  pdf_base.txt  and add the path to where
    echo     your Ellis_Messina folder lives on the USB drive.
    echo     Example:  E:\Ellis_Messina
    echo.
    echo   OPTION C: No PDFs (search only)
    echo     The app works fully without PDFs — you can still search
    echo     all 83,684 records and look up WoRMS taxonomy.
    echo.
)

:done
echo =====================================================================
echo   INSTALLATION COMPLETE
echo =====================================================================
echo.
echo To start the web search app:
echo   Double-click  run.bat
echo.
echo To export the database to Excel:
echo   Double-click  export_excel.bat
echo.
echo The app will open in your browser at http://127.0.0.1:5050
echo.
echo NOTE: Keep the black command window open while using the app.
echo       Closing it will stop the app.
echo.
pause
