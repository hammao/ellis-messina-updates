#!/bin/bash
# =====================================================================
#  Ellis & Messina Search — macOS / Linux Launcher
#  Run this every time you want to start the app.
# =====================================================================

cd "$(dirname "$0")/../.."   # run from app root

# Activate virtual environment if present
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# Build database if missing
if [ ! -f "em_database.db" ]; then
    echo "Database not found. Building now..."
    python3 build_database.py
fi

echo "Starting Ellis & Messina Search..."
echo "Browser will open at http://127.0.0.1:5050"
echo "Press Ctrl+C to stop."
echo ""
python3 run.py
