#!/bin/bash
# Ellis & Messina — Export to Excel
# Run this to create Ellis_Messina_Database.xlsx

cd "$(dirname "$0")/../.."

if [ -d "venv" ]; then
    source venv/bin/activate
fi

echo "Exporting to Excel (takes ~15 seconds for 83K records)..."
python3 tools/export_to_excel.py

if [ $? -eq 0 ]; then
    echo ""
    echo "Done! Open Ellis_Messina_Database.xlsx to search offline."
else
    echo "Export failed. Run install.sh first."
fi
