#!/bin/bash
# =====================================================================
#  Ellis & Messina Search — macOS / Linux Installer
#  Run once after copying the app folder to your computer.
# =====================================================================

set -e
cd "$(dirname "$0")/../.."   # run from the app root (two levels up from deploy/mac_linux/)

echo ""
echo "====================================================================="
echo "  Ellis & Messina Micropaleontology Search"
echo "  macOS / Linux Installer"
echo "====================================================================="
echo ""

# ── Check we're in the right place ───────────────────────────────────
if [ ! -f "run.py" ]; then
    echo "ERROR: run.py not found in current directory."
    echo "This script must be inside deploy/mac_linux/ within the app folder."
    exit 1
fi

# ── Check Python 3 ───────────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "ERROR: Python 3 not found."
    echo ""
    echo "Install it:"
    echo "  macOS:   brew install python3"
    echo "           (or download from https://www.python.org/downloads/)"
    echo "  Ubuntu:  sudo apt install python3 python3-venv python3-pip"
    echo "  CentOS:  sudo dnf install python3"
    exit 1
fi

echo "Python found: $(python3 --version)"
echo ""

# ── Create virtual environment ────────────────────────────────────────
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    echo "Done."
    echo ""
fi

# ── Install packages ──────────────────────────────────────────────────
echo "Installing required packages..."
source venv/bin/activate
pip install --quiet flask requests rapidfuzz openpyxl
echo "Packages installed."
echo ""

# ── Build database ────────────────────────────────────────────────────
if [ -f "em_database.db" ]; then
    echo "Search database found — skipping build."
elif [ -f "downloads/metadata/foraminifera_metadata.json" ]; then
    echo "Building search database from metadata files..."
    echo "(Takes about 5 seconds)"
    python3 build_database.py
    echo "Database built successfully."
else
    echo ""
    echo "WARNING: Metadata files not found in downloads/metadata/"
    echo ""
    echo "The app needs these three files:"
    echo "  downloads/metadata/foraminifera_metadata.json"
    echo "  downloads/metadata/ostracoda_metadata.json"
    echo "  downloads/metadata/diatoms_metadata.json"
    echo ""
    echo "Copy these files, then run install.sh again to build the database."
fi

# ── Make run.sh executable ────────────────────────────────────────────
chmod +x "deploy/mac_linux/run.sh" 2>/dev/null || true

echo ""
echo "====================================================================="
echo "  INSTALLATION COMPLETE"
echo "====================================================================="
echo ""
echo "To start the app:"
echo "  ./deploy/mac_linux/run.sh"
echo "  or: python3 run.py"
echo ""
echo "Your browser will open at http://127.0.0.1:5050"
echo ""
