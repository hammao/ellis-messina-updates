# gunicorn.conf.py — Production WSGI config for Ellis & Messina Search
#
# Usage:
#   gunicorn -c deploy/server/gunicorn.conf.py app:app

import multiprocessing, os

bind    = "127.0.0.1:5050"          # Nginx proxies to this; change to 0.0.0.0:5050 if no Nginx
workers = 2                          # 2 is fine for a lab server; (2 * CPU cores + 1) for heavy use
worker_class = "sync"
timeout      = 120                   # generous timeout for PDF serving
keepalive    = 5

# Logging (directory must exist)
_log_dir = os.path.join(os.path.dirname(__file__), "..", "..", "logs")
os.makedirs(_log_dir, exist_ok=True)
accesslog = os.path.join(_log_dir, "gunicorn_access.log")
errorlog  = os.path.join(_log_dir, "gunicorn_error.log")
loglevel  = "info"

# Restart workers after N requests to prevent memory creep
max_requests      = 500
max_requests_jitter = 50
