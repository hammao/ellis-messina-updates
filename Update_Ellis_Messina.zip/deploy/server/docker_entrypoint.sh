#!/bin/bash
set -e

# Build database from metadata JSONs if the DB doesn't exist yet
if [ ! -f "em_database.db" ] && [ -d "downloads/metadata" ]; then
    echo "[entrypoint] Building database from metadata files..."
    python build_database.py
fi

if [ ! -f "em_database.db" ]; then
    echo "[entrypoint] WARNING: em_database.db not found."
    echo "  Mount it with: -v \$(pwd)/em_database.db:/app/em_database.db"
    echo "  The app will start but search will not work."
fi

echo "[entrypoint] Starting Gunicorn on port 5050..."
exec gunicorn \
    --bind 0.0.0.0:5050 \
    --workers 2 \
    --timeout 120 \
    --access-logfile - \
    --error-logfile - \
    app:app
