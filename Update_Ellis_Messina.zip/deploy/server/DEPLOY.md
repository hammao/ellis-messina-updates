# Ellis & Messina Search — Server Deployment Guide

This guide covers four hosting options, from simplest to most capable.

---

## Which option should I choose?

| Option | Who can access | PDFs | Internet needed | Cost |
|---|---|---|---|---|
| **A. Local PC** | You only | Yes | No | Free |
| **B. Local network** | Anyone on same Wi-Fi/LAN | Yes | No | Free |
| **C. Dedicated server** | Anyone with the URL | Yes | Initial setup | ~$6/month VPS |
| **D. Cloud (lite)** | Anyone with the URL | No | Yes | Free tier available |

---

## Option A — Local PC (already working)

```bash
python3 run.py           # macOS/Linux
python run.py            # Windows (after running install.bat)
```

Opens at http://127.0.0.1:5050 — accessible only on your machine.

---

## Option B — Local Network Server

Run the app on any PC and share it with everyone on the same
Wi-Fi or wired network (lab, office, home).

**Start the server:**
```bash
python3 run.py --host 0.0.0.0 --no-browser
```

**Find your IP address:**
```bash
# macOS/Linux:
ipconfig getifaddr en0      # Wi-Fi
hostname -I                  # Linux

# Windows:
ipconfig                    # look for IPv4 Address
```

**Share the link:**
Anyone on your network can open:  `http://YOUR_IP:5050`

Example: `http://192.168.1.42:5050`

**Make it permanent (runs in background on Linux/macOS):**
```bash
nohup python3 run.py --host 0.0.0.0 --no-browser &
```

Or use the systemd service (see Option C below).

---

## Option C — Dedicated Linux Server (full version, with PDFs)

Best for a university or lab server that stays on 24/7.
Gives a permanent URL like `http://micropaleontology.kfupm.edu.sa`

### Step 1 — Provision a server

Any Linux server works (Ubuntu 22.04 recommended):
- University-managed server: contact your IT department
- Cloud VPS: DigitalOcean, Hetzner, Linode (~$5–12/month)
  - Choose a server with enough disk: 50 GB for app + DB, 40 TB for PDFs

### Step 2 — Transfer files to the server

```bash
# From your local machine:
rsync -avz --exclude 'downloads/Foraminifera' \
           --exclude 'downloads/Ostracoda' \
           --exclude 'downloads/Diatoms' \
           --exclude '__pycache__' \
           --exclude 'venv' \
           /path/to/Ellis_Messina/ \
           ubuntu@YOUR_SERVER_IP:~/Ellis_Messina/

# Transfer the database separately (30 MB):
scp em_database.db ubuntu@YOUR_SERVER_IP:~/Ellis_Messina/

# Transfer PDFs if needed (35 GB — use screen or tmux, takes hours):
rsync -avz downloads/Foraminifera/ ubuntu@YOUR_SERVER_IP:~/Ellis_Messina/downloads/Foraminifera/
rsync -avz downloads/Ostracoda/    ubuntu@YOUR_SERVER_IP:~/Ellis_Messina/downloads/Ostracoda/
rsync -avz downloads/Diatoms/      ubuntu@YOUR_SERVER_IP:~/Ellis_Messina/downloads/Diatoms/
```

### Step 3 — Install on the server

```bash
ssh ubuntu@YOUR_SERVER_IP
cd ~/Ellis_Messina

# Install Python dependencies
python3 -m venv venv
source venv/bin/activate
pip install flask requests rapidfuzz openpyxl gunicorn

# Install Nginx
sudo apt update && sudo apt install -y nginx
```

### Step 4 — Configure Nginx

```bash
# Edit the nginx.conf template to set your domain/IP
nano deploy/server/nginx.conf
# Change: server_name YOUR_DOMAIN_OR_IP;

# Install the config
sudo cp deploy/server/nginx.conf /etc/nginx/sites-available/ellis_messina
sudo ln -s /etc/nginx/sites-available/ellis_messina \
           /etc/nginx/sites-enabled/
sudo nginx -t          # test config
sudo systemctl reload nginx
```

### Step 5 — Set up auto-start with systemd

```bash
# Edit the service file to set your username and paths
nano deploy/server/ellis_messina.service
# Change the three lines marked EDIT

# Install and start
sudo cp deploy/server/ellis_messina.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable ellis_messina
sudo systemctl start  ellis_messina

# Check status
sudo systemctl status ellis_messina
```

### Step 6 — (Optional) Add HTTPS with Let's Encrypt

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
# Certbot automatically renews certificates every 90 days
```

Your app is now at: `https://your-domain.com`

### Managing the service

```bash
sudo systemctl stop    ellis_messina   # stop
sudo systemctl start   ellis_messina   # start
sudo systemctl restart ellis_messina   # restart after code changes
sudo journalctl -u ellis_messina -f    # live logs
```

---

## Option D — Cloud Hosting (lite version, no PDFs)

Host the app for free on cloud platforms. PDFs cannot be served
(35 GB files), but all other features work: search, WoRMS taxonomy,
distribution maps, and GBIF images.

### Sub-option D1 — PythonAnywhere (free tier)

PythonAnywhere gives a free Python web hosting account with a
`yourusername.pythonanywhere.com` URL and 512 MB storage.

1. Sign up at https://www.pythonanywhere.com (free)
2. Open a **Bash console** and run:
   ```bash
   git clone YOUR_GITHUB_REPO_URL
   cd Ellis_Messina
   pip3 install --user flask requests rapidfuzz openpyxl
   python3 build_database.py
   ```
3. Go to **Web** tab → Add a new web app → Manual config → Python 3.11
4. Set **Source code**: `/home/USERNAME/Ellis_Messina`
5. Set **WSGI file** to point to `app.py`:
   ```python
   # /var/www/USERNAME_pythonanywhere_com_wsgi.py
   import sys
   sys.path.insert(0, '/home/USERNAME/Ellis_Messina')
   from app import app as application
   ```
6. **Reload** the web app — it's live at `USERNAME.pythonanywhere.com`

**Limitation**: Free tier sleeps after 3 months of inactivity; reload
monthly to keep it alive. Upgrade to $5/month for always-on.

### Sub-option D2 — Render (free tier, Docker)

Render can deploy directly from GitHub using the included Dockerfile.

1. Push your code to GitHub (see below — exclude large files)
2. Sign up at https://render.com
3. New → Web Service → Connect your GitHub repo
4. Settings:
   - **Environment**: Docker
   - **Dockerfile path**: `deploy/server/Dockerfile`
   - **Plan**: Free (512 MB RAM, sleeps after 15 min inactivity)
5. Add **Environment variable**: `PORT=5050`
6. Add a **Persistent Disk** (paid, $0.25/GB/month) and mount at `/app`
   to preserve the SQLite database across restarts

### Sub-option D3 — Local server + Cloudflare Tunnel (free, with PDFs)

Run the app on your own PC/NAS but make it accessible anywhere with
a public URL — no port-forwarding, no public IP required.

1. Install the app on your always-on PC/NAS
2. Start: `python3 run.py --host 0.0.0.0 --no-browser`
3. Install Cloudflare Tunnel:
   ```bash
   # Linux:
   curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 \
        -o cloudflared && chmod +x cloudflared

   # macOS:
   brew install cloudflare/cloudflare/cloudflared
   ```
4. Create a tunnel:
   ```bash
   cloudflared tunnel --url http://localhost:5050
   ```
   This prints a URL like `https://abc-xyz.trycloudflare.com`

5. Share that URL — it works from anywhere, even without a static IP.
   For a permanent URL, sign up for a free Cloudflare account and
   set up a named tunnel with your own domain.

---

## Putting the code on GitHub

If you want to share the **code** (not the 35 GB PDFs), create a
`.gitignore` so only the app source is committed:

```
# .gitignore
downloads/
em_database.db
worms_images/
venv/
__pycache__/
*.pyc
logs/
*.xlsx
dist/
build/
```

Then:
```bash
git init
git add .
git commit -m "Initial commit — Ellis & Messina Search App"
git remote add origin https://github.com/YOUR_USERNAME/ellis-messina-search.git
git push -u origin main
```

The `em_database.db` (30 MB) can be shared as a **GitHub Release asset**
so colleagues can download it without cloning the full repo.

---

## Quick reference: all start commands

| Scenario | Command |
|---|---|
| Local only | `python3 run.py` |
| LAN sharing | `python3 run.py --host 0.0.0.0` |
| Background (no browser) | `python3 run.py --host 0.0.0.0 --no-browser` |
| Custom port | `python3 run.py --port 8080` |
| Production (Gunicorn) | `gunicorn -c deploy/server/gunicorn.conf.py app:app` |
| Docker | `docker run -p 5050:5050 -v $(pwd)/em_database.db:/app/em_database.db ellis-messina` |
