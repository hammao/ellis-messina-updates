#!/usr/bin/env python3
"""
precache_worms.py — Bulk pre-cache WoRMS taxonomy for the most-searched genera.

Looks up the top N genera (by record count in the E&M database), then fetches
WoRMS data for representative species from each genus.  Results land in the
SQLite worms_cache table so subsequent browser lookups are instant.

Usage:
    python3 precache_worms.py              # top-50 genera, 3 names each
    python3 precache_worms.py --genera 100 # top-100 genera
    python3 precache_worms.py --per 5      # 5 names per genus
    python3 precache_worms.py --database Foraminifera   # one database only
    python3 precache_worms.py --dry-run    # list names without fetching
"""

import argparse
import sqlite3
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.resolve()
DB_PATH      = PROJECT_ROOT / "em_database.db"


def get_representative_names(
    db: sqlite3.Connection,
    database: str | None,
    top_genera: int,
    per_genus: int,
) -> list[str]:
    """
    Return up to top_genera×per_genus taxon names, ordered by genus frequency.
    Picks the most frequent species within each genus to maximise cache hit rate.
    """
    db_filter = "AND database = ?" if database else ""
    params_base = [database] if database else []

    # Rank genera by record count
    genera_sql = f"""
        SELECT genus, COUNT(*) AS cnt
        FROM records
        WHERE genus IS NOT NULL AND genus != ''
        {db_filter}
        GROUP BY genus
        ORDER BY cnt DESC
        LIMIT ?
    """
    top = db.execute(genera_sql, params_base + [top_genera]).fetchall()

    names: list[str] = []
    for (genus, _) in top:
        species_sql = f"""
            SELECT taxon_name, COUNT(*) AS cnt
            FROM records
            WHERE genus = ? {db_filter}
            GROUP BY taxon_name
            ORDER BY cnt DESC
            LIMIT ?
        """
        rows = db.execute(
            species_sql, [genus] + params_base + [per_genus]
        ).fetchall()
        names.extend(r[0] for r in rows)

    return names


def run(top_genera: int, per_genus: int,
        database: str | None, dry_run: bool) -> None:
    if not DB_PATH.exists():
        print(f"ERROR: Database not found at {DB_PATH}", file=sys.stderr)
        sys.exit(1)

    conn = sqlite3.connect(str(DB_PATH))
    names = get_representative_names(conn, database, top_genera, per_genus)
    conn.close()

    label = f"top-{top_genera} genera × {per_genus} names each"
    db_label = database or "all databases"
    print(f"\nEllis & Messina WoRMS pre-cache — {label} ({db_label})")
    print(f"Total names to process: {len(names)}")
    print()

    if dry_run:
        for i, n in enumerate(names, 1):
            print(f"  {i:4d}. {n}")
        return

    from worms_integration import lookup, get_cache_stats

    stats_before = get_cache_stats()
    hits = skips = errors = 0

    for i, name in enumerate(names, 1):
        # Brief progress every 10 names
        if i % 10 == 0 or i == 1:
            print(f"  [{i}/{len(names)}] Processing…")

        try:
            result = lookup(name, use_cache=True)   # skips if already fresh
            if result.get("from_cache"):
                skips += 1
            elif result.get("found"):
                hits += 1
            else:
                hits += 1   # not_found is still a valid cache entry
        except Exception as e:
            errors += 1
            print(f"    ERROR for {name!r}: {e}")

        # Polite pause between live API calls (worms_integration rate-limits,
        # but an extra small sleep avoids bursts on cache misses)
        time.sleep(0.1)

    stats_after = get_cache_stats()
    new_entries = stats_after["total_cached"] - stats_before["total_cached"]

    print()
    print("Done.")
    print(f"  New cache entries : {new_entries}")
    print(f"  Already cached    : {skips}")
    print(f"  Errors            : {errors}")
    print(f"  Total in cache    : {stats_after['total_cached']}")
    print(f"    → found         : {stats_after['found']}")
    print(f"    → not found     : {stats_after['not_found']}")
    print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Bulk pre-cache WoRMS taxonomy for the most common genera.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 precache_worms.py                      # top-50 genera, 3 names each
  python3 precache_worms.py --genera 100 --per 5
  python3 precache_worms.py --database Foraminifera
  python3 precache_worms.py --dry-run            # just list names
        """,
    )
    parser.add_argument("--genera", type=int, default=50, metavar="N",
                        help="Number of top genera to process (default: 50)")
    parser.add_argument("--per", type=int, default=3, metavar="N",
                        help="Names per genus (default: 3)")
    parser.add_argument("--database", choices=["Foraminifera", "Ostracoda", "Diatoms"],
                        default=None, help="Restrict to one database (default: all)")
    parser.add_argument("--dry-run", action="store_true",
                        help="List names without making any API calls")
    args = parser.parse_args()

    run(
        top_genera=args.genera,
        per_genus=args.per,
        database=args.database,
        dry_run=args.dry_run,
    )
