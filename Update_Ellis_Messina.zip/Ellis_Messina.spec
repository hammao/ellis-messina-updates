# -*- mode: python ; coding: utf-8 -*-
#
# Ellis_Messina.spec — PyInstaller build specification
#
# Usage (Windows):
#   pyinstaller Ellis_Messina.spec
#
# Usage (Mac/Linux):
#   pyinstaller Ellis_Messina.spec
#
# Output:
#   dist/Ellis_Messina_Search/Ellis_Messina_Search.exe   (Windows)
#   dist/Ellis_Messina_Search/Ellis_Messina_Search       (Mac/Linux)
#   dist/Ellis_Messina_Search/em_database.db             (alongside the exe)
#
# Distribute to the end-user:
#   - The entire  dist/Ellis_Messina_Search/  folder (on a USB drive)
#   - Optionally: the  downloads/  folder with PDFs (also on the USB drive)
#     Place it INSIDE dist/Ellis_Messina_Search/ so relative paths resolve.

import os
from pathlib import Path

root = Path(SPEC.split(os.sep)[0]).parent if hasattr(SPEC, 'split') else Path('.')
# Fallback: let PyInstaller resolve relative paths from cwd
root = Path.cwd()

a = Analysis(
    ['run.py'],
    pathex=[str(root)],
    binaries=[],
    datas=[
        # Bundle templates and static into the executable package
        ('templates', 'templates'),
        ('static',    'static'),
        # DO NOT bundle em_database.db here — it lives next to the .exe
        # so users can rebuild it without repackaging
    ],
    hiddenimports=[
        # Flask internals that PyInstaller sometimes misses
        'flask',
        'flask.templating',
        'jinja2',
        'jinja2.ext',
        'werkzeug',
        'werkzeug.serving',
        'werkzeug.routing',
        'werkzeug.exceptions',
        'click',
        # Our modules
        'app',
        'search',
        'worms_integration',
        'build_database',
        # Deps
        'rapidfuzz',
        'requests',
        'urllib3',
        'charset_normalizer',
        'certifi',
        'sqlite3',
        'json',
        'threading',
        'webbrowser',
        'socket',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Exclude unused heavy packages
        'matplotlib',
        'numpy',
        'pandas',
        'PIL',
        'PyInstaller',
        'tkinter',        # we use Flask, not tkinter
        'pyinstaller',
        'test',
        'unittest',
    ],
    noarchive=False,
    optimize=1,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,          # one-folder mode (faster startup than --onefile)
    name='Ellis_Messina_Search',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,                       # compress with UPX if available
    console=True,                   # show console window so users can see startup progress
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,                      # add an .ico file path here if you have one
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='Ellis_Messina_Search',    # → dist/Ellis_Messina_Search/
)
