#!/usr/bin/env python3
"""
build_database.py — Convert Ellis & Messina JSON metadata to SQLite with FTS5.

Run once (or when JSON files change):
    python build_database.py
    python build_database.py --force   # force full rebuild
    python build_database.py --quiet   # suppress progress output
"""

import json
import sqlite3
import argparse
import time
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.resolve()
DB_PATH = PROJECT_ROOT / "em_database.db"
METADATA_DIR = PROJECT_ROOT / "downloads" / "metadata"

DATABASE_FILES = {
    "Foraminifera": METADATA_DIR / "foraminifera_metadata.json",
    "Ostracoda": METADATA_DIR / "ostracoda_metadata.json",
    "Diatoms": METADATA_DIR / "diatoms_metadata.json",
}

# ------------------------------------------------------------------
# Schema DDL
# ------------------------------------------------------------------

_DDL_RECORDS = """
CREATE TABLE IF NOT EXISTS records (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    taxon_name     TEXT    NOT NULL,
    genus          TEXT    NOT NULL DEFAULT '',
    species        TEXT    NOT NULL DEFAULT '',
    subgenus       TEXT    NOT NULL DEFAULT '',
    subspecies     TEXT    NOT NULL DEFAULT '',
    variety        TEXT    NOT NULL DEFAULT '',
    author         TEXT    NOT NULL DEFAULT '',
    year           INTEGER,
    record_id      TEXT    NOT NULL,
    database       TEXT    NOT NULL,
    pdf_path       TEXT,
    pdf_downloaded INTEGER NOT NULL DEFAULT 0,
    pdf_size_bytes INTEGER NOT NULL DEFAULT 0,
    original_url   TEXT    NOT NULL DEFAULT '',
    UNIQUE(database, record_id)
);
CREATE INDEX IF NOT EXISTS idx_genus    ON records(genus    COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_author   ON records(author   COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_year     ON records(year);
CREATE INDEX IF NOT EXISTS idx_database ON records(database);
CREATE INDEX IF NOT EXISTS idx_pdf      ON records(pdf_downloaded);
"""

_DDL_FTS = """
CREATE VIRTUAL TABLE IF NOT EXISTS records_fts USING fts5(
    taxon_name,
    genus,
    species,
    subgenus,
    subspecies,
    variety,
    author,
    content = records,
    content_rowid = id,
    tokenize = "unicode61 remove_diacritics 1"
);
"""

_DDL_WORMS = """
CREATE TABLE IF NOT EXISTS worms_cache (
    taxon_name      TEXT PRIMARY KEY,
    aphia_id        INTEGER,
    status          TEXT,
    valid_name      TEXT,
    valid_authority TEXT,
    kingdom         TEXT,
    phylum          TEXT,
    class           TEXT,
    "order"         TEXT,
    family          TEXT,
    genus           TEXT,
    synonyms_json   TEXT,
    worms_url       TEXT,
    is_marine       INTEGER,
    is_extinct      INTEGER,
    fetched_at      TEXT NOT NULL,
    error           TEXT
);
CREATE INDEX IF NOT EXISTS idx_worms_aphia ON worms_cache(aphia_id);
"""

_DDL_META = """
CREATE TABLE IF NOT EXISTS db_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


# ------------------------------------------------------------------
# Record parsing
# ------------------------------------------------------------------

def _parse_record(raw: dict, db_name: str) -> tuple | None:
    """Parse a raw JSON record dict into a tuple for INSERT, or None to skip."""
    taxon_name = (raw.get("taxon_name") or "").strip()
    record_id = str(raw.get("record_id") or "").strip()

    # Skip sentinel / blank records
    if not taxon_name or record_id in ("0", "", "None"):
        return None

    year_raw = str(raw.get("year") or "").strip()
    try:
        year = int(year_raw) if year_raw.isdigit() else None
    except (ValueError, TypeError):
        year = None
    # Treat year 0 as unknown
    if year == 0:
        year = None

    # pdf_path: take first available path
    pdf_path = raw.get("pdf_path") or None
    if not pdf_path:
        paths = raw.get("pdf_paths") or []
        if isinstance(paths, list) and paths:
            pdf_path = paths[0]
        elif isinstance(paths, str) and paths:
            pdf_path = paths

    pdf_downloaded = 1 if raw.get("pdf_downloaded") else 0
    pdf_size = raw.get("pdf_size_bytes") or 0

    return (
        taxon_name,
        (raw.get("genus") or "").strip(),
        (raw.get("species") or "").strip(),
        (raw.get("subgenus") or "").strip(),
        (raw.get("subspecies") or "").strip(),
        (raw.get("variety") or "").strip(),
        (raw.get("author") or "").strip(),
        year,
        record_id,
        db_name,
        pdf_path if pdf_path else None,
        pdf_downloaded,
        pdf_size,
        (raw.get("original_url") or "").strip(),
    )


# ------------------------------------------------------------------
# Cache-invalidation check
# ------------------------------------------------------------------

def check_needs_rebuild() -> bool:
    """Return True if DB doesn't exist or JSON files have changed since last build."""
    if not DB_PATH.exists():
        return True
    try:
        conn = sqlite3.connect(DB_PATH)
        rows = dict(conn.execute("SELECT key, value FROM db_meta").fetchall())
        conn.close()
    except Exception:
        return True

    for db_name, json_path in DATABASE_FILES.items():
        if not json_path.exists():
            continue
        stored_key = f"json_size_{db_name.lower()}"
        stored_size = rows.get(stored_key)
        actual_size = str(json_path.stat().st_size)
        if stored_size != actual_size:
            return True
    return False


# ------------------------------------------------------------------
# Main build function
# ------------------------------------------------------------------

def build(force: bool = False, verbose: bool = True) -> dict:
    """
    Build (or rebuild) em_database.db from JSON metadata files.

    Returns:
        dict with keys: built (bool), total (int), by_database (dict), elapsed (float)
    """
    t0 = time.time()

    if not force and not check_needs_rebuild():
        # DB is current — just read the count
        try:
            conn = sqlite3.connect(DB_PATH)
            total = int(conn.execute(
                "SELECT value FROM db_meta WHERE key = 'total_count'"
            ).fetchone()[0])
            conn.close()
        except Exception:
            total = 0
        return {"built": False, "total": total, "by_database": {}, "elapsed": 0.0}

    def log(msg: str):
        if verbose:
            print(msg)

    log(f"Building SQLite database at {DB_PATH} ...")

    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA cache_size = -65536")   # 64 MB page cache
    conn.execute("PRAGMA temp_store = MEMORY")

    # Drop and recreate records tables (NOT worms_cache — preserve cached lookups)
    conn.executescript("""
        DROP TABLE IF EXISTS records_fts;
        DROP TABLE IF EXISTS records;
        DROP TABLE IF EXISTS db_meta;
    """)

    conn.executescript(_DDL_RECORDS)
    conn.executescript(_DDL_FTS)
    conn.executescript(_DDL_META)   # db_meta recreated above
    conn.executescript(_DDL_WORMS)  # worms_cache: CREATE IF NOT EXISTS (preserved)

    by_database: dict[str, int] = {}
    total_inserted = 0
    total_skipped = 0

    insert_sql = """
        INSERT OR IGNORE INTO records
        (taxon_name, genus, species, subgenus, subspecies, variety,
         author, year, record_id, database, pdf_path,
         pdf_downloaded, pdf_size_bytes, original_url)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """

    for db_name, json_path in DATABASE_FILES.items():
        if not json_path.exists():
            log(f"  WARNING: {json_path} not found — skipping {db_name}")
            by_database[db_name] = 0
            continue

        log(f"  Loading {db_name} from {json_path.name} ...")
        with open(json_path, "r", encoding="utf-8") as fh:
            raw_records = json.load(fh)

        if not isinstance(raw_records, list):
            log(f"  WARNING: {json_path.name} is not a JSON array — skipping")
            by_database[db_name] = 0
            continue

        batch: list[tuple] = []
        skipped = 0
        for raw in raw_records:
            parsed = _parse_record(raw, db_name)
            if parsed is None:
                skipped += 1
                continue
            batch.append(parsed)

        conn.executemany(insert_sql, batch)
        conn.commit()

        count = conn.execute(
            "SELECT COUNT(*) FROM records WHERE database = ?", (db_name,)
        ).fetchone()[0]
        by_database[db_name] = count
        total_inserted += count
        total_skipped += skipped
        log(f"    {count:,} records inserted, {skipped:,} skipped")

    # Build FTS index from records table
    log("  Building FTS5 index ...")
    conn.execute("""
        INSERT INTO records_fts(rowid, taxon_name, genus, species,
                                subgenus, subspecies, variety, author)
        SELECT id, taxon_name, genus, species,
               subgenus, subspecies, variety, author
        FROM records
    """)
    conn.commit()

    # Write db_meta
    build_date = datetime.utcnow().isoformat() + "Z"
    meta_rows = [
        ("build_date", build_date),
        ("total_count", str(total_inserted)),
        ("skipped_count", str(total_skipped)),
    ]
    for db_name, count in by_database.items():
        meta_rows.append((f"{db_name.lower()}_count", str(count)))
    for db_name, json_path in DATABASE_FILES.items():
        if json_path.exists():
            meta_rows.append((f"json_size_{db_name.lower()}", str(json_path.stat().st_size)))

    conn.executemany("INSERT OR REPLACE INTO db_meta(key, value) VALUES (?,?)", meta_rows)
    conn.commit()
    conn.close()

    elapsed = time.time() - t0
    log(f"\nDone: {total_inserted:,} records in {elapsed:.1f}s → {DB_PATH}")

    return {
        "built": True,
        "total": total_inserted,
        "by_database": by_database,
        "elapsed": elapsed,
    }


# ------------------------------------------------------------------
# CLI
# ------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build Ellis & Messina SQLite database")
    parser.add_argument("--force", action="store_true", help="Force full rebuild")
    parser.add_argument("--quiet", action="store_true", help="Suppress progress output")
    args = parser.parse_args()

    result = build(force=args.force, verbose=not args.quiet)
    if not result["built"]:
        print(f"Database is already current ({result['total']:,} records). "
              f"Use --force to rebuild.")
    else:
        print(f"\nSummary:")
        for db_name, count in result["by_database"].items():
            print(f"  {db_name}: {count:,}")
        print(f"  Total:  {result['total']:,}")
        print(f"  Time:   {result['elapsed']:.1f}s")
