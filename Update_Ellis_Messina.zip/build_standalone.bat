@echo off
REM =====================================================================
REM  build_standalone.bat — Build Ellis & Messina Search as a Windows .exe
REM
REM  Run this once on a Windows machine that has Python installed.
REM  The output in  dist\Ellis_Messina_Search\  can then be copied to a
REM  USB drive and given to anyone with a Windows PC (no Python needed).
REM =====================================================================

echo.
echo =====================================================================
echo   Ellis ^& Messina Search — Windows Standalone Build
echo =====================================================================
echo.

REM -- Check Python -------------------------------------------------------
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.9+ from python.org
    pause
    exit /b 1
)

REM -- Check / install PyInstaller ----------------------------------------
python -c "import PyInstaller" >nul 2>&1
if errorlevel 1 (
    echo Installing PyInstaller...
    pip install pyinstaller
    if errorlevel 1 (
        echo ERROR: Failed to install PyInstaller.
        pause
        exit /b 1
    )
)

REM -- Build the SQLite database if it doesn't exist ----------------------
if not exist em_database.db (
    echo Building SQLite database from JSON metadata...
    python build_database.py
    if errorlevel 1 (
        echo ERROR: Database build failed.
        pause
        exit /b 1
    )
    echo.
)

REM -- Clean previous builds ----------------------------------------------
echo Cleaning previous build files...
if exist build   rmdir /s /q build
if exist dist    rmdir /s /q dist

REM -- Run PyInstaller ----------------------------------------------------
echo Building executable...
echo.
pyinstaller Ellis_Messina.spec

if errorlevel 1 (
    echo.
    echo BUILD FAILED. Check the error messages above.
    pause
    exit /b 1
)

REM -- Copy the database next to the .exe ---------------------------------
echo.
echo Copying database to dist folder...
copy /y em_database.db "dist\Ellis_Messina_Search\em_database.db"
if errorlevel 1 (
    echo WARNING: Could not copy em_database.db — copy it manually.
)

REM -- Summary ------------------------------------------------------------
echo.
echo =====================================================================
echo   BUILD SUCCESSFUL
echo =====================================================================
echo.
echo   Output folder:  dist\Ellis_Messina_Search\
echo.
echo   TO SHARE WITH SOMEONE:
echo   1. Copy the entire  dist\Ellis_Messina_Search\  folder to a USB drive
echo   2. (Optional) Also copy the  downloads\  folder to the USB drive
echo      so the recipient can open PDFs directly from the app.
echo   3. On the recipient's PC: open the USB drive, go into
echo      Ellis_Messina_Search\ and double-click  Ellis_Messina_Search.exe
echo   4. A browser will open automatically at http://127.0.0.1:5050
echo.
echo   NOTE: Windows may show a SmartScreen warning on first run.
echo   Click "More info" then "Run anyway".
echo.
pause
