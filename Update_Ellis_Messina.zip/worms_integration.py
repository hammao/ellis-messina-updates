"""
worms_integration.py — WoRMS (World Register of Marine Species) REST API wrapper.

Data fetched per lookup (for accepted taxa):
  • AphiaRecordsByName       → status, valid name, 6-level classification,
                               lsid, citation, all habitat flags, rank, modified
  • AphiaSynonymsByAphiaID   → full synonym list
  • AphiaSourcesByAphiaID    → bibliographic references (original description, etc.)
  • AphiaDistributionsByAphiaID → geographic localities
  • AphiaClassificationByAphiaID → complete hierarchy (Superdomain → Species)

All results cached in SQLite worms_cache table (30-day TTL).
Works fully offline after first lookup.

WoRMS API docs: https://www.marinespecies.org/rest/
"""

import json
import re
import sqlite3
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional
from urllib.parse import quote as url_quote

try:
    import requests as _requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    _REQUESTS_AVAILABLE = False

import sys as _sys
if getattr(_sys, "frozen", False):
    PROJECT_ROOT = Path(_sys.executable).parent.resolve()
else:
    PROJECT_ROOT = Path(__file__).parent.resolve()
DB_PATH = PROJECT_ROOT / "em_database.db"

WORMS_BASE = "https://www.marinespecies.org/rest"
GBIF_BASE  = "https://api.gbif.org/v1"
MR_BASE    = "https://www.marineregions.org/rest"   # Marine Regions MRGID coords
PBDB_BASE    = "https://paleobiodb.org/data1.2"     # Paleobiology Database (fossil taxa)
MIKROTAX_BASE = "https://www.mikrotax.org/system/index.php"
# Module mapping by Ellis & Messina database name
MIKROTAX_MODULES = {
    "Foraminifera": "pf_cenozoic",   # also covers most mesozoic forams via search
    "Diatoms":      "diatoms",
    # Ostracoda: not in Mikrotax — omit
}
CACHE_TTL_DAYS = 30
CACHE_TTL_NOT_FOUND_DAYS = 3   # retry not_found quickly (API may add taxa)
REQUEST_TIMEOUT = 10
_RATE_DELAY = 0.2          # seconds between API calls (polite crawling)
MAX_IMAGES = 5             # maximum images to download per taxon
IMAGES_DIR = PROJECT_ROOT / "worms_images"

_last_request_time = 0.0
_worms_conn: Optional[sqlite3.Connection] = None


# ------------------------------------------------------------------
# DB connection + schema migration
# ------------------------------------------------------------------

def _get_worms_db() -> sqlite3.Connection:
    global _worms_conn
    if _worms_conn is None:
        if not DB_PATH.exists():
            raise FileNotFoundError(
                f"Database not found at {DB_PATH}. Run: python3 build_database.py"
            )
        _worms_conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        _worms_conn.row_factory = sqlite3.Row
        _worms_conn.execute("PRAGMA journal_mode = WAL")
        _ensure_worms_table()
    return _worms_conn


def _ensure_worms_table():
    """Create worms_cache table if missing, then migrate any new columns."""
    _worms_conn.executescript("""
        CREATE TABLE IF NOT EXISTS mrgid_coords (
            mrgid       INTEGER PRIMARY KEY,
            lat         REAL,
            lon         REAL,
            place_name  TEXT,
            fetched_at  TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS worms_cache (
            taxon_name      TEXT PRIMARY KEY,
            aphia_id        INTEGER,
            status          TEXT,
            valid_name      TEXT,
            valid_authority TEXT,
            kingdom         TEXT,
            phylum          TEXT,
            class           TEXT,
            "order"         TEXT,
            family          TEXT,
            genus           TEXT,
            synonyms_json   TEXT,
            worms_url       TEXT,
            is_marine       INTEGER,
            is_extinct      INTEGER,
            fetched_at      TEXT NOT NULL,
            error           TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_worms_aphia ON worms_cache(aphia_id);
    """)
    _worms_conn.commit()

    # Migrate: add new columns if they don't already exist
    new_cols = [
        ("lsid",                "TEXT"),
        ("citation",            "TEXT"),
        ("is_brackish",         "INTEGER"),
        ("is_freshwater",       "INTEGER"),
        ("is_terrestrial",      "INTEGER"),
        ("rank",                "TEXT"),
        ("modified",            "TEXT"),
        ("unaccept_reason",     "TEXT"),
        ("sources_json",        "TEXT"),
        ("distribution_json",   "TEXT"),
        ("classification_json", "TEXT"),
        ("media_json",          "TEXT"),
    ]
    for col_name, col_type in new_cols:
        try:
            _worms_conn.execute(
                f'ALTER TABLE worms_cache ADD COLUMN "{col_name}" {col_type}'
            )
            _worms_conn.commit()
        except sqlite3.OperationalError:
            pass  # Column already exists — safe to ignore


# ------------------------------------------------------------------
# Cache read / write
# ------------------------------------------------------------------

def _get_cached(cache_key: str) -> Optional[dict]:
    row = _get_worms_db().execute(
        "SELECT * FROM worms_cache WHERE taxon_name = ?", (cache_key,)
    ).fetchone()
    return dict(row) if row else None


def _is_fresh(fetched_at: str, status: str = None) -> bool:
    try:
        dt = datetime.fromisoformat(fetched_at.replace("Z", "+00:00"))
        ttl = CACHE_TTL_NOT_FOUND_DAYS if status in ("not_found", "error") else CACHE_TTL_DAYS
        return datetime.now(timezone.utc) - dt < timedelta(days=ttl)
    except Exception:
        return False


def _bool_flag(val) -> Optional[int]:
    """Convert WoRMS 0/1/null flag to SQLite INTEGER or None."""
    if val is None:
        return None
    return 1 if val else 0


def _save_cache(result: dict):
    conn = _get_worms_db()
    c = result.get("classification") or {}
    conn.execute(
        """INSERT OR REPLACE INTO worms_cache
           (taxon_name, aphia_id, status, valid_name, valid_authority,
            kingdom, phylum, class, "order", family, genus,
            synonyms_json, worms_url, is_marine, is_extinct, fetched_at, error,
            lsid, citation, is_brackish, is_freshwater, is_terrestrial,
            rank, modified, unaccept_reason,
            sources_json, distribution_json, classification_json, media_json)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            result["_cache_key"],
            result.get("aphia_id"),
            result.get("status"),
            result.get("valid_name"),
            result.get("valid_authority"),
            c.get("kingdom"), c.get("phylum"), c.get("class"),
            c.get("order"), c.get("family"), c.get("genus"),
            json.dumps(result.get("synonyms") or []),
            result.get("worms_url"),
            _bool_flag(result.get("is_marine")),
            _bool_flag(result.get("is_extinct")),
            result.get("fetched_at", datetime.utcnow().isoformat() + "Z"),
            result.get("error"),
            result.get("lsid"),
            result.get("citation"),
            _bool_flag(result.get("is_brackish")),
            _bool_flag(result.get("is_freshwater")),
            _bool_flag(result.get("is_terrestrial")),
            result.get("rank"),
            result.get("modified"),
            result.get("unaccept_reason"),
            json.dumps(result.get("sources") or []),
            json.dumps(result.get("distribution") or []),
            json.dumps(result.get("full_classification") or []),
            json.dumps(result.get("media") or []),
        ),
    )
    conn.commit()


def _load_json(row: dict, key: str) -> list:
    try:
        return json.loads(row.get(key) or "[]") or []
    except (ValueError, TypeError):
        return []


def _flag(row: dict, key: str) -> Optional[bool]:
    v = row.get(key)
    return bool(v) if v is not None else None


def _deserialize_cache(row: dict, from_cache: bool = True) -> dict:
    found = row.get("status") not in (None, "not_found", "error")
    return {
        "taxon_name":        row["taxon_name"],
        "found":             found,
        "aphia_id":          row.get("aphia_id"),
        "status":            row.get("status") or "not_found",
        "valid_name":        row.get("valid_name"),
        "valid_authority":   row.get("valid_authority"),
        "rank":              row.get("rank"),
        "lsid":              row.get("lsid"),
        "citation":          row.get("citation"),
        "modified":          row.get("modified"),
        "unaccept_reason":   row.get("unaccept_reason"),
        "classification": {
            "kingdom": row.get("kingdom"), "phylum": row.get("phylum"),
            "class":   row.get("class"),   "order":  row.get("order"),
            "family":  row.get("family"),  "genus":  row.get("genus"),
        },
        "full_classification": _load_json(row, "classification_json"),
        "synonyms":            _load_json(row, "synonyms_json"),
        "sources":             _load_json(row, "sources_json"),
        "distribution":        _load_json(row, "distribution_json"),
        "media":               _load_json(row, "media_json"),
        "worms_url":           row.get("worms_url"),
        "is_marine":           _flag(row, "is_marine"),
        "is_brackish":         _flag(row, "is_brackish"),
        "is_freshwater":       _flag(row, "is_freshwater"),
        "is_terrestrial":      _flag(row, "is_terrestrial"),
        "is_extinct":          _flag(row, "is_extinct"),
        "fetched_at":          row.get("fetched_at", ""),
        "from_cache":          from_cache,
        "error":               row.get("error"),
    }


# ------------------------------------------------------------------
# HTTP helper
# ------------------------------------------------------------------

def _get(url: str, params: dict = None) -> Optional[list | dict]:
    global _last_request_time
    if not _REQUESTS_AVAILABLE:
        return None

    elapsed = time.time() - _last_request_time
    if elapsed < _RATE_DELAY:
        time.sleep(_RATE_DELAY - elapsed)

    try:
        resp = _requests.get(url, params=params, timeout=REQUEST_TIMEOUT,
                             headers={"User-Agent": "EllisMessina-OfflineSearch/1.0"})
        _last_request_time = time.time()
        if resp.status_code == 204:
            return []
        if resp.status_code == 404:
            return None
        if not resp.ok:
            return None
        text = resp.text.strip()
        return resp.json() if text else []
    except Exception:
        _last_request_time = time.time()
        return None


# ------------------------------------------------------------------
# Mikrotax URL builder
# ------------------------------------------------------------------

def mikrotax_url(taxon_name: str, database: str = "Foraminifera") -> Optional[str]:
    """
    Return the Mikrotax page URL for a given taxon name and E&M database type.
    Returns None for Ostracoda (not in Mikrotax).
    The Mikrotax JSON API currently returns empty responses; we provide links only.
    """
    module = MIKROTAX_MODULES.get(database)
    if not module:
        return None
    return f"{MIKROTAX_BASE}?taxon={url_quote(taxon_name)}&module={module}"


# ------------------------------------------------------------------
# Paleobiology Database fallback (for fossil taxa excluded by WoRMS API)
# ------------------------------------------------------------------

def _lookup_pbdb(taxon_name: str) -> dict:
    """
    Try PBDB when WoRMS name-search returns nothing.

    The WoRMS REST API silently excludes extinct taxa from all name-search
    endpoints (returns 204 even though the record exists by AphiaID).
    PBDB covers fossil foraminifera, ostracods, and diatoms.
    """
    if not _REQUESTS_AVAILABLE:
        return {"found": False}

    try:
        # Use requests directly — PBDB wraps results in {"records": [...]}
        resp = _requests.get(
            f"{PBDB_BASE}/taxa/single.json",
            params={"name": taxon_name, "show": "app,class,ref"},
            timeout=REQUEST_TIMEOUT,
            headers={"User-Agent": "EllisMessina-OfflineSearch/1.0"},
        )
        if not resp.ok or resp.status_code == 404:
            return {"found": False}
        records = resp.json().get("records", [])
        if not records:
            return {"found": False}

        rec = records[0]
        raw_id = rec.get("oid", "")  # "txn:355109"
        pbdb_id = int(raw_id.split(":")[-1]) if ":" in raw_id else None

        is_synonym = bool(rec.get("tdf"))  # tdf = "subjective synonym of" etc.
        return {
            "found":          True,
            "pbdb_id":        pbdb_id,
            "pbdb_url":       (f"https://paleobiodb.org/classic/basicTaxonInfo"
                               f"?taxon_no={pbdb_id}") if pbdb_id else None,
            "name":           rec.get("nam"),
            "status":         "synonym" if is_synonym else "accepted",
            "accepted_name":  rec.get("acn"),  # only set when synonym
            "phylum":         rec.get("phl"),
            "class":          rec.get("cll"),
            "order":          rec.get("odl"),
            "family":         rec.get("fml"),
            "genus":          rec.get("gnl"),
            "first_interval": rec.get("tei"),   # e.g. "Lutetian"
            "last_interval":  rec.get("tli"),   # e.g. "Messinian"
            "first_ma_early": rec.get("fea"),   # Ma (early bound of first appearance)
            "last_ma_late":   rec.get("lla"),   # Ma (late bound of last appearance)
            "occurrences":    rec.get("noc", 0),
            "reference":      (rec.get("ref", "") or "")[:300] or None,
        }
    except Exception as e:
        return {"found": False, "error": str(e)}


# ------------------------------------------------------------------
# Additional fetchers
# ------------------------------------------------------------------

def _fetch_synonyms(aphia_id: int) -> list[dict]:
    data = _get(f"{WORMS_BASE}/AphiaSynonymsByAphiaID/{aphia_id}") or []
    return [
        {
            "name":      r.get("scientificname", ""),
            "authority": r.get("authority", ""),
            "status":    r.get("status", ""),
            "rank":      r.get("rank", ""),
        }
        for r in data if isinstance(r, dict)
    ]


def _fetch_sources(aphia_id: int) -> list[dict]:
    data = _get(f"{WORMS_BASE}/AphiaSourcesByAphiaID/{aphia_id}") or []
    return [
        {
            "use":       r.get("use", ""),
            "reference": r.get("reference", ""),
            "doi":       r.get("doi"),
            "page":      r.get("page"),
            "url":       r.get("url"),
        }
        for r in data if isinstance(r, dict) and r.get("reference")
    ]


def _fetch_distribution(aphia_id: int) -> list[dict]:
    data = _get(f"{WORMS_BASE}/AphiaDistributionsByAphiaID/{aphia_id}") or []
    seen = set()
    result = []
    for r in data:
        if not isinstance(r, dict):
            continue
        if r.get("recordStatus") != "valid":
            continue
        locality = r.get("locality", "")
        if locality in seen:
            continue
        seen.add(locality)

        # Extract integer MRGID from locationID URL
        # e.g. "http://marineregions.org/mrgid/1902" → 1902
        mrgid = None
        loc_id = (r.get("locationID") or "").rstrip("/")
        if loc_id:
            try:
                mrgid = int(loc_id.rsplit("/", 1)[-1])
            except (ValueError, IndexError):
                pass

        result.append({
            "locality":         locality,
            "higher_geography": r.get("higherGeography", ""),
            "type_status":      r.get("typeStatus"),
            "mrgid":            mrgid,
            "lat":              None,   # filled by _enrich_distribution_with_coords
            "lon":              None,
        })
    return result


def _enrich_distribution_with_coords(distribution: list[dict]) -> list[dict]:
    """
    Adds lat/lon to each distribution entry by looking up the MRGID
    (Marine Regions Geographic ID) in a local SQLite cache, then falling
    back to the Marine Regions REST API for any that are missing.
    """
    if not distribution:
        return distribution

    conn = _get_worms_db()
    needed = {d["mrgid"] for d in distribution if d.get("mrgid") is not None}
    if not needed:
        return distribution

    # Batch-read from local cache
    ph = ",".join("?" * len(needed))
    rows = conn.execute(
        f"SELECT mrgid, lat, lon FROM mrgid_coords WHERE mrgid IN ({ph})",
        list(needed),
    ).fetchall()
    coord_map: dict[int, tuple] = {r["mrgid"]: (r["lat"], r["lon"]) for r in rows}

    # Fetch missing from Marine Regions API
    if _REQUESTS_AVAILABLE:
        for mrgid in needed:
            if mrgid in coord_map:
                continue
            mr = _get(f"{MR_BASE}/getGazetteerRecordByMRGID.json/{mrgid}/")
            lat = lon = None
            place_name = ""
            if isinstance(mr, dict):
                try:
                    lat = float(mr["latitude"])  if mr.get("latitude")  is not None else None
                    lon = float(mr["longitude"]) if mr.get("longitude") is not None else None
                except (TypeError, ValueError):
                    pass
                place_name = mr.get("preferredGazetteerName", "")
            coord_map[mrgid] = (lat, lon)
            conn.execute(
                "INSERT OR REPLACE INTO mrgid_coords "
                "(mrgid, lat, lon, place_name, fetched_at) VALUES (?,?,?,?,?)",
                (mrgid, lat, lon, place_name,
                 datetime.utcnow().isoformat() + "Z"),
            )
        conn.commit()

    # Annotate each entry
    for entry in distribution:
        mrgid = entry.get("mrgid")
        if mrgid is not None and mrgid in coord_map:
            entry["lat"], entry["lon"] = coord_map[mrgid]

    return distribution


def _fetch_full_classification(aphia_id: int) -> list[dict]:
    """Flatten the nested classification tree into an ordered list."""
    data = _get(f"{WORMS_BASE}/AphiaClassificationByAphiaID/{aphia_id}")
    if not data or not isinstance(data, dict):
        return []
    result = []
    node = data
    while node:
        name = node.get("scientificname", "")
        rank = node.get("rank", "")
        if name and rank:
            result.append({"rank": rank, "name": name, "aphia_id": node.get("AphiaID")})
        node = node.get("child")
    return result


# ------------------------------------------------------------------
# GBIF image fetching
# ------------------------------------------------------------------

def _ext_from_format(fmt: str) -> str:
    fmt = (fmt or "").lower()
    if "png"  in fmt: return ".png"
    if "gif"  in fmt: return ".gif"
    if "tiff" in fmt or "tif" in fmt: return ".tif"
    return ".jpg"


def _download_image(url: str, dest: Path) -> bool:
    """Download a single image to dest. Returns True on success."""
    global _last_request_time
    try:
        elapsed = time.time() - _last_request_time
        if elapsed < _RATE_DELAY:
            time.sleep(_RATE_DELAY - elapsed)
        resp = _requests.get(
            url, timeout=15, stream=True,
            headers={"User-Agent": "EllisMessina-OfflineSearch/1.0"},
        )
        _last_request_time = time.time()
        if not resp.ok:
            return False
        max_bytes = 5 * 1024 * 1024      # 5 MB cap per image
        downloaded = 0
        with open(dest, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    downloaded += len(chunk)
                    if downloaded > max_bytes:
                        fh.close()
                        dest.unlink(missing_ok=True)
                        return False
                    fh.write(chunk)
        return True
    except Exception:
        if dest.exists():
            dest.unlink(missing_ok=True)
        return False


def _image_subdir_name(aphia_id: int, taxon_name: str) -> str:
    """
    Build a human-readable subdirectory name that encodes both the unique
    AphiaID and the species name so the folder is self-explanatory on disk.
    Example: 112772_Triloculina_trigonula
    """
    # Take first two words of the name (genus + epithet), strip the rest
    words = taxon_name.strip().split()[:2]
    safe = "_".join(re.sub(r"[^\w]", "_", w) for w in words)
    return f"{aphia_id}_{safe}"[:80]


def _fetch_gbif_images(taxon_name: str, aphia_id: int) -> list[dict]:
    """
    Fetch up to MAX_IMAGES specimen images from GBIF for this taxon.
    Downloads them locally to worms_images/{aphia_id}/ for offline use.
    Returns a list of dicts with url, local_path, creator, license, title.
    """
    if not _REQUESTS_AVAILABLE:
        return []

    # Step 1 — match taxon name → GBIF usageKey
    match_data = _get(f"{GBIF_BASE}/species/match",
                      params={"name": taxon_name, "verbose": "false"})
    if not isinstance(match_data, dict):
        return []
    if match_data.get("matchType") == "NONE":
        return []
    usage_key = match_data.get("usageKey")
    confidence = match_data.get("confidence", 0)
    if not usage_key or confidence < 80:
        return []

    collected: list[dict] = []

    # Step 2 — scientific illustrations from species media endpoint
    sp_media = _get(f"{GBIF_BASE}/species/{usage_key}/media") or []
    if isinstance(sp_media, list):
        for m in sp_media:
            if not isinstance(m, dict) or not m.get("identifier"):
                continue
            if len(collected) >= MAX_IMAGES:
                break
            collected.append({
                "url":     m["identifier"],
                "creator": m.get("creator") or m.get("rightsHolder"),
                "license": m.get("license"),
                "title":   m.get("title") or m.get("description"),
                "format":  m.get("format", "image/jpeg"),
                "type":    "illustration",
            })

    # Step 3 — occurrence images (most taxa have these)
    if len(collected) < MAX_IMAGES:
        limit = (MAX_IMAGES - len(collected)) + 10   # over-fetch; dedupe below
        occ_data = _get(f"{GBIF_BASE}/occurrence/search",
                        params={"taxonKey": usage_key,
                                "mediaType": "StillImage",
                                "limit": limit})
        if isinstance(occ_data, dict):
            for occ in occ_data.get("results", []):
                if len(collected) >= MAX_IMAGES:
                    break
                for m in (occ.get("media") or []):
                    if len(collected) >= MAX_IMAGES:
                        break
                    if m.get("type") == "StillImage" and m.get("identifier"):
                        collected.append({
                            "url":     m["identifier"],
                            "creator": m.get("creator"),
                            "license": m.get("license"),
                            "title":   m.get("title"),
                            "format":  m.get("format", "image/jpeg"),
                            "type":    "occurrence",
                        })

    if not collected:
        return []

    # Step 4 — download locally into a named subdirectory
    # Format: worms_images/{aphia_id}_{Genus_species}/
    # This makes the folder immediately identifiable on disk without
    # having to cross-reference the AphiaID.
    subdir_name = _image_subdir_name(aphia_id, taxon_name)
    img_dir     = IMAGES_DIR / subdir_name
    img_dir.mkdir(parents=True, exist_ok=True)

    # Write a metadata file so the folder is self-documenting
    meta_path = img_dir / "species.json"
    if not meta_path.exists():
        meta_path.write_text(json.dumps({
            "aphia_id":    aphia_id,
            "taxon_name":  taxon_name,
            "worms_url":   f"https://www.marinespecies.org/aphia.php?p=taxdetails&id={aphia_id}",
            "downloaded_at": datetime.utcnow().isoformat() + "Z",
            "source":      "GBIF occurrence/species media endpoint",
            "license_note": "Images are CC-BY; see individual 'license' fields.",
        }, indent=2))

    result = []
    for i, m in enumerate(collected[:MAX_IMAGES]):
        ext       = _ext_from_format(m.get("format", ""))
        filename  = f"{i}{ext}"
        local_abs = img_dir / filename
        rel_path  = f"worms_images/{subdir_name}/{filename}"

        if not local_abs.exists():
            if not _download_image(m["url"], local_abs):
                result.append({**m, "local_path": None})
                continue

        result.append({**m, "local_path": rel_path})

    return result


# ------------------------------------------------------------------
# Best-match selector
# ------------------------------------------------------------------

def _pick_best_match(taxon_name: str, records: list) -> dict:
    name_lower = taxon_name.strip().lower()
    exact_accepted = [
        r for r in records
        if (r.get("scientificname") or "").lower() == name_lower
        and r.get("status") == "accepted"
    ]
    if exact_accepted:
        return exact_accepted[0]
    exact_any = [
        r for r in records
        if (r.get("scientificname") or "").lower() == name_lower
    ]
    return exact_any[0] if exact_any else records[0]


# ------------------------------------------------------------------
# Name cleaning helpers
# ------------------------------------------------------------------

def _extract_binomial(name: str) -> Optional[str]:
    """
    Extract 'Genus species' from messy Ellis & Messina taxon strings.

    Handles patterns common in 19th/20th-century micropaleontology literature:
      'Triloculina trigonula (Lamarck) var. multistriata'
      'Rotalia beccarii (Linné, 1758) var. aculeata'
      'Globigerina bulloides d\'Orbigny, 1826'
      'Quinqueloculina seminula subsp. parvula'

    Returns the two-word binomial, or None if the input is already ≤2 words.
    """
    # Remove parenthetical author/year: (Lamarck) or (d'Orbigny, 1826)
    cleaned = re.sub(r'\([^)]*\)', '', name)
    # Remove infraspecific rank keywords and everything after
    cleaned = re.sub(
        r'\b(var|subvar|subsp|ssp|f|forma|nov|sp|aff|cf|sensu)\b.*',
        '', cleaned, flags=re.IGNORECASE,
    )
    # Remove trailing author cruft: comma + anything
    cleaned = re.sub(r',.*', '', cleaned)
    words = cleaned.split()
    if not words:
        return None
    binomial = ' '.join(words[:2]) if len(words) >= 2 else words[0]
    # Only useful if it's actually shorter than the original
    return binomial if binomial.lower() != name.strip().lower() else None


# ------------------------------------------------------------------
# Result builders
# ------------------------------------------------------------------

def _build_result(taxon_name: str, cache_key: str, record: dict,
                  synonyms: list, sources: list,
                  distribution: list, full_classification: list) -> dict:
    aphia_id     = record.get("AphiaID")
    status       = record.get("status", "") or "accepted"
    valid_name   = record.get("valid_name") or record.get("scientificname")
    valid_auth   = record.get("valid_authority") or record.get("authority")
    worms_url    = record.get("url") or (
        f"https://www.marinespecies.org/aphia.php?p=taxdetails&id={aphia_id}"
        if aphia_id else None
    )
    return {
        "_cache_key":          cache_key,
        "taxon_name":          taxon_name,
        "found":               True,
        "aphia_id":            aphia_id,
        "status":              status,
        "valid_name":          valid_name,
        "valid_authority":     valid_auth,
        "rank":                record.get("rank"),
        "lsid":                record.get("lsid"),
        "citation":            record.get("citation"),
        "modified":            record.get("modified", "")[:10] if record.get("modified") else None,
        "unaccept_reason":     record.get("unacceptreason"),
        "classification": {
            "kingdom": record.get("kingdom"), "phylum": record.get("phylum"),
            "class":   record.get("class"),   "order":  record.get("order"),
            "family":  record.get("family"),  "genus":  record.get("genus"),
        },
        "full_classification": full_classification,
        "synonyms":            synonyms,
        "sources":             sources,
        "distribution":        distribution,
        "worms_url":           worms_url,
        "is_marine":           bool(record["isMarine"])    if record.get("isMarine")    is not None else None,
        "is_brackish":         bool(record["isBrackish"])  if record.get("isBrackish")  is not None else None,
        "is_freshwater":       bool(record["isFreshwater"])if record.get("isFreshwater")is not None else None,
        "is_terrestrial":      bool(record["isTerrestrial"])if record.get("isTerrestrial")is not None else None,
        "is_extinct":          bool(record["isExtinct"])   if record.get("isExtinct")   is not None else None,
        "fetched_at":          datetime.utcnow().isoformat() + "Z",
        "from_cache":          False,
        "error":               None,
        "media":               [],   # populated by lookup() after GBIF fetch
    }


def _empty_result(taxon_name: str, cache_key: str,
                  status: str = "not_found", error: str = None) -> dict:
    return {
        "_cache_key": cache_key, "taxon_name": taxon_name,
        "found": False, "aphia_id": None, "status": status,
        "valid_name": None, "valid_authority": None, "rank": None,
        "lsid": None, "citation": None, "modified": None, "unaccept_reason": None,
        "classification": {k: None for k in ("kingdom","phylum","class","order","family","genus")},
        "full_classification": [], "synonyms": [], "sources": [], "distribution": [],
        "worms_url": None, "is_marine": None, "is_brackish": None,
        "is_freshwater": None, "is_terrestrial": None, "is_extinct": None,
        "fetched_at": datetime.utcnow().isoformat() + "Z",
        "from_cache": False, "error": error, "media": [], "pbdb": None,
    }


# ------------------------------------------------------------------
# Main lookup
# ------------------------------------------------------------------

def lookup(taxon_name: str, use_cache: bool = True) -> dict:
    """
    Look up a taxon in WoRMS. Returns a rich dict with taxonomy,
    synonyms, sources, distribution, habitat, and identifiers.
    Results are cached locally for 30 days.
    """
    taxon_name = (taxon_name or "").strip()
    if not taxon_name:
        return _empty_result("", "", "error", "Empty taxon name")

    cache_key = taxon_name.lower()

    if use_cache:
        cached = _get_cached(cache_key)
        if cached and _is_fresh(cached.get("fetched_at", ""), cached.get("status")):
            result = _deserialize_cache(cached, from_cache=True)
            # Always augment extinct taxa with PBDB stratigraphic data (not stored in cache)
            if result.get("is_extinct") or not result["found"]:
                result["pbdb"] = _lookup_pbdb(taxon_name)
            return result

    if not _REQUESTS_AVAILABLE:
        cached = _get_cached(cache_key)
        if cached:
            return _deserialize_cache(cached, from_cache=True)
        return _empty_result(taxon_name, cache_key, "error",
                             "requests library not available (offline)")

    # Step 1: Primary name lookup (exact)
    url  = f"{WORMS_BASE}/AphiaRecordsByName/{url_quote(taxon_name)}"
    data = _get(url, params={"like": "false", "marine_only": "false"})

    # Step 2: Fallback — partial/like match on full name
    if not data:
        data = _get(url, params={"like": "true", "marine_only": "false"})

    # Step 3: Fallback — strip author/var/subsp and retry with core binomial
    #   Handles names like "Triloculina trigonula (Lamarck) var. multistriata"
    #   where WoRMS only knows "Triloculina trigonula"
    if not data:
        binomial = _extract_binomial(taxon_name)
        if binomial:
            bin_url = f"{WORMS_BASE}/AphiaRecordsByName/{url_quote(binomial)}"
            data = _get(bin_url, params={"like": "false", "marine_only": "false"})
            if not data:
                data = _get(bin_url, params={"like": "true", "marine_only": "false"})

    # Step 4: extant_only=false — WoRMS Feb 2025 API change exposes extinct/fossil taxa
    if not data:
        data = _get(url, params={"like": "false", "extant_only": "false"})

    # Step 5: extant_only=false with partial match
    if not data:
        data = _get(url, params={"like": "true", "extant_only": "false"})

    if data is None:
        result = _empty_result(taxon_name, cache_key, "error", "WoRMS API request failed")
        _save_cache(result)
        return result

    if not data:
        result = _empty_result(taxon_name, cache_key, "not_found")
        result["pbdb"] = _lookup_pbdb(taxon_name)   # fallback for extinct taxa
        _save_cache(result)
        return result

    record   = _pick_best_match(taxon_name, data)
    aphia_id = record.get("AphiaID")

    # Step 3–6: Extra fetches for accepted taxa (or the valid taxon of a synonym)
    lookup_id = aphia_id
    if record.get("status") != "accepted" and record.get("valid_AphiaID"):
        lookup_id = record["valid_AphiaID"]

    synonyms         = _fetch_synonyms(aphia_id)          if aphia_id  else []
    sources          = _fetch_sources(lookup_id)          if lookup_id else []
    distribution     = _enrich_distribution_with_coords(
                           _fetch_distribution(lookup_id) if lookup_id else []
                       )
    full_class       = _fetch_full_classification(lookup_id) if lookup_id else []

    result = _build_result(taxon_name, cache_key, record,
                           synonyms, sources, distribution, full_class)

    # Step 7: Fetch images from GBIF (downloads locally for offline use)
    result["media"] = _fetch_gbif_images(taxon_name, aphia_id) if aphia_id else []

    # Step 8: For extinct taxa, enrich with PBDB stratigraphic/occurrence data
    #   WoRMS has excellent taxonomy; PBDB adds stratigraphic ranges and fossil occurrences
    if result.get("is_extinct"):
        result["pbdb"] = _lookup_pbdb(taxon_name)
    else:
        result["pbdb"] = None

    _save_cache(result)
    return result


def lookup_many(names: list[str], use_cache: bool = True) -> list[dict]:
    return [lookup(n, use_cache=use_cache) for n in names]


# ------------------------------------------------------------------
# Cache stats
# ------------------------------------------------------------------

def get_cache_stats() -> dict:
    conn = _get_worms_db()
    total    = conn.execute("SELECT COUNT(*) FROM worms_cache").fetchone()[0]
    found    = conn.execute("SELECT COUNT(*) FROM worms_cache WHERE status NOT IN ('not_found','error')").fetchone()[0]
    return {"total_cached": total, "found": found,
            "not_found": total - found,
            "errors": conn.execute("SELECT COUNT(*) FROM worms_cache WHERE status='error'").fetchone()[0]}


if __name__ == "__main__":
    import sys
    name = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "Triloculina plicata"
    print(f"Looking up: {name!r}")
    result = lookup(name, use_cache=False)
    result.pop("_cache_key", None)
    print(json.dumps(result, indent=2))
