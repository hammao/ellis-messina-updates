"""
Check for new records in Ellis & Messina database and download them
"""
import os
import sys
import json
import logging
from datetime import datetime
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from downloader.authenticator import Authenticator
from downloader.scraper import Scraper
from downloader.downloader import FileDownloader
from downloader.organizer import FileOrganizer
from downloader.utils import setup_logging
import config
from tools.update_config import *
from tools.send_email import send_update_email

def get_local_record_count(database: str) -> int:
    """Get count of records in local metadata"""
    metadata_file = Path(__file__).parent.parent / "downloads" / "metadata" / f"{database}_metadata.json"
    
    if not metadata_file.exists():
        return 0
    
    try:
        with open(metadata_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return len(data) if isinstance(data, list) else 0
    except Exception as e:
        logging.error(f"Error reading local metadata for {database}: {e}")
        return 0

def get_local_record_ids(database: str) -> set:
    """Get set of all record IDs in local metadata"""
    metadata_file = Path(__file__).parent.parent / "downloads" / "metadata" / f"{database}_metadata.json"
    
    record_ids = set()
    if not metadata_file.exists():
        return record_ids
    
    try:
        with open(metadata_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            for record in data:
                record_id = record.get('record_id', '')
                if record_id:
                    record_ids.add(str(record_id))
    except Exception as e:
        logging.error(f"Error reading record IDs for {database}: {e}")
    
    return record_ids

def get_website_record_count(scraper: Scraper, database: str) -> int:
    """Get total record count from website"""
    try:
        # Perform a broad search to get total count
        response = scraper.search_records(database=database, page=1)
        total_pages = scraper.get_total_pages(response)
        # Estimate: 50 records per page (approximate)
        return total_pages * 50
    except Exception as e:
        logging.error(f"Error getting website record count for {database}: {e}")
        return 0

def discover_new_records(scraper: Scraper, database: str, local_record_ids: set, max_pages: int = 100) -> list:
    """Discover new records by comparing website with local records"""
    new_records = []
    seen_urls = set()
    
    logging.info(f"Scanning website for new {database} records...")
    
    try:
        # Get total pages
        initial_response = scraper.search_records(database=database, page=1)
        total_pages = scraper.get_total_pages(initial_response)
        total_pages = min(total_pages, max_pages)  # Limit for update check
        
        logging.info(f"Scanning {total_pages} pages for new records...")
        
        # Scan pages to find new records
        for page in range(1, total_pages + 1):
            try:
                response = scraper.search_records(database=database, page=page)
                records = scraper.parse_search_results(response)
                
                for record in records:
                    record_id = str(record.get('record_id', ''))
                    record_url = record.get('url', '')
                    
                    # Check if this is a new record
                    if record_id and record_id not in local_record_ids:
                        if record_url and record_url not in seen_urls:
                            record['database'] = database
                            new_records.append(record)
                            seen_urls.add(record_url)
                            local_record_ids.add(record_id)  # Track to avoid duplicates
                
                if page % 50 == 0:
                    logging.info(f"Scanned {page}/{total_pages} pages, found {len(new_records)} new records so far...")
                
            except Exception as e:
                logging.warning(f"Error scanning page {page}: {e}")
                continue
        
        logging.info(f"Found {len(new_records)} new records for {database}")
        
    except Exception as e:
        logging.error(f"Error discovering new records for {database}: {e}")
    
    return new_records

def download_new_records(new_records: list, database: str, scraper: Scraper, downloader: FileDownloader, organizer: FileOrganizer) -> dict:
    """Download new records"""
    if not new_records:
        return {'downloaded': 0, 'failed': 0, 'errors': []}
    
    output_dir = organizer.get_database_dir(database)
    results = {'downloaded': 0, 'failed': 0, 'errors': []}
    
    logging.info(f"Downloading {len(new_records)} new records for {database}...")
    
    for i, record in enumerate(new_records, 1):
        try:
            # Get PDF URLs
            if not record.get('pdf_urls') and not record.get('pdf_url'):
                details = scraper.get_taxon_details(record)
                record.update(details)
            
            # Download files
            download_results = downloader.download_record_files(record, output_dir, organizer=organizer)
            
            # Save metadata
            organizer.save_record_metadata(record, download_results)
            
            if download_results.get('pdf_downloaded'):
                results['downloaded'] += 1
            else:
                results['failed'] += 1
                results['errors'].append(f"Record {record.get('record_id', 'unknown')}: No PDF downloaded")
            
            if i % 10 == 0:
                logging.info(f"Downloaded {i}/{len(new_records)} new records...")
                
        except Exception as e:
            results['failed'] += 1
            error_msg = f"Record {record.get('record_id', 'unknown')}: {str(e)}"
            results['errors'].append(error_msg)
            logging.error(error_msg)
    
    # Save updated metadata
    organizer.save_metadata_files()
    
    return results

def generate_update_report(new_records_by_db: dict, download_results_by_db: dict) -> str:
    """Generate update report text"""
    report = []
    report.append("=" * 60)
    report.append("Ellis & Messina Database Update Report")
    report.append(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("=" * 60)
    report.append("")
    
    total_new = 0
    total_downloaded = 0
    total_failed = 0
    
    for database in ['foraminifera', 'ostracoda', 'diatoms']:
        if database not in new_records_by_db:
            continue
        
        new_records = new_records_by_db[database]
        download_results = download_results_by_db.get(database, {})
        
        report.append(f"Database: {database.capitalize()}")
        report.append(f"  New records found: {len(new_records)}")
        report.append(f"  Successfully downloaded: {download_results.get('downloaded', 0)}")
        report.append(f"  Failed downloads: {download_results.get('failed', 0)}")
        report.append("")
        
        if new_records:
            report.append("  New Records:")
            for record in new_records[:20]:  # Show first 20
                taxon = record.get('taxon_name', '') or f"{record.get('genus', '')} {record.get('species', '')}".strip()
                record_id = record.get('record_id', 'unknown')
                report.append(f"    - {taxon} (ID: {record_id})")
            if len(new_records) > 20:
                report.append(f"    ... and {len(new_records) - 20} more")
            report.append("")
        
        if download_results.get('errors'):
            report.append("  Errors:")
            for error in download_results['errors'][:10]:  # Show first 10 errors
                report.append(f"    - {error}")
            if len(download_results['errors']) > 10:
                report.append(f"    ... and {len(download_results['errors']) - 10} more errors")
            report.append("")
        
        total_new += len(new_records)
        total_downloaded += download_results.get('downloaded', 0)
        total_failed += download_results.get('failed', 0)
    
    report.append("=" * 60)
    report.append(f"Summary:")
    report.append(f"  Total new records found: {total_new}")
    report.append(f"  Total successfully downloaded: {total_downloaded}")
    report.append(f"  Total failed: {total_failed}")
    report.append("=" * 60)
    
    return "\n".join(report)

def save_update_report(report: str):
    """Save update report to file"""
    os.makedirs(UPDATE_REPORT_DIR, exist_ok=True)
    report_file = os.path.join(UPDATE_REPORT_DIR, f"new_records_{datetime.now().strftime('%Y-%m-%d')}.txt")
    
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(report)
    
    logging.info(f"Update report saved: {report_file}")
    return report_file

def check_for_updates():
    """Main function to check for updates"""
    logger = setup_logging(config.LOG_DIR)
    logger.info("=" * 60)
    logger.info("Ellis & Messina Database Update Check")
    logger.info("=" * 60)
    
    # Authenticate
    logger.info("Authenticating...")
    authenticator = Authenticator(
        config.CREDENTIALS['username'],
        config.CREDENTIALS['password']
    )
    
    if not authenticator.login():
        logger.error("Authentication failed")
        return False
    
    if not authenticator.verify_authentication():
        logger.error("Authentication verification failed")
        return False
    
    logger.info("Authentication successful")
    
    # Initialize components
    session = authenticator.get_session()
    scraper = Scraper(session)
    downloader = FileDownloader(session, base_session=session)
    organizer = FileOrganizer()
    
    # Databases to check
    databases_to_check = []
    if CHECK_FORAMINIFERA:
        databases_to_check.append('foraminifera')
    if CHECK_OSTRACODA:
        databases_to_check.append('ostracoda')
    if CHECK_DIATOMS:
        databases_to_check.append('diatoms')
    
    new_records_by_db = {}
    download_results_by_db = {}
    
    # Check each database
    for database in databases_to_check:
        logger.info(f"\n{'=' * 60}")
        logger.info(f"Checking {database} database...")
        logger.info(f"{'=' * 60}")
        
        # Get local record count
        local_count = get_local_record_count(database)
        logger.info(f"Local records: {local_count}")
        
        # Get website record count (approximate)
        website_count = get_website_record_count(scraper, database)
        logger.info(f"Website records (approx): {website_count}")
        
        if website_count <= local_count:
            logger.info(f"No new records detected for {database}")
            new_records_by_db[database] = []
            download_results_by_db[database] = {'downloaded': 0, 'failed': 0, 'errors': []}
            continue
        
        # Get local record IDs
        local_record_ids = get_local_record_ids(database)
        logger.info(f"Local record IDs: {len(local_record_ids)}")
        
        # Discover new records
        new_records = discover_new_records(scraper, database, local_record_ids, max_pages=50)
        new_records_by_db[database] = new_records
        
        if new_records:
            # Download new records
            download_results = download_new_records(new_records, database, scraper, downloader, organizer)
            download_results_by_db[database] = download_results
            logger.info(f"Downloaded {download_results['downloaded']} new records for {database}")
        else:
            download_results_by_db[database] = {'downloaded': 0, 'failed': 0, 'errors': []}
    
    # Generate report
    report = generate_update_report(new_records_by_db, download_results_by_db)
    
    # Console output
    if NOTIFY_CONSOLE:
        print("\n" + report)
    
    # File output
    if NOTIFY_FILE:
        report_file = save_update_report(report)
        logger.info(f"Report saved to: {report_file}")
    
    # Email output
    if NOTIFY_EMAIL and EMAIL_ENABLED:
        try:
            send_update_email(report, new_records_by_db, download_results_by_db)
            logger.info("Update email sent")
        except Exception as e:
            logger.error(f"Failed to send email: {e}")
    
    logger.info("Update check complete")
    return True

if __name__ == "__main__":
    check_for_updates()

