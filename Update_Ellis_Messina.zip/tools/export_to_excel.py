#!/usr/bin/env python3
"""
tools/export_to_excel.py — Export the Ellis & Messina SQLite database to Excel.

Generates a self-contained .xlsx file that anyone with Microsoft Excel can use
to search and filter the database offline — no Python, no internet required.

Usage:
    python tools/export_to_excel.py
    python tools/export_to_excel.py --output "MySearch.xlsx"
    python tools/export_to_excel.py --database Foraminifera   # export one DB only
    python tools/export_to_excel.py --pdf-only                # only records with PDFs

Output:
    Ellis_Messina_Database.xlsx  (~30–45 MB for all databases)
"""

import argparse
import sqlite3
import sys
import time
from pathlib import Path

try:
    import openpyxl
    from openpyxl.styles import (
        Font, PatternFill, Alignment, Border, Side, GradientFill
    )
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo
    from openpyxl.worksheet.filters import AutoFilter
except ImportError:
    print("ERROR: openpyxl is required.  Run:  pip install openpyxl")
    sys.exit(1)

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
DB_PATH = PROJECT_ROOT / "em_database.db"

# ------------------------------------------------------------------
# Colours
# ------------------------------------------------------------------
NAVY        = "1A3A5C"
LIGHT_BLUE  = "E8F0FA"
WHITE       = "FFFFFF"
GREEN_BG    = "DCFCE7"
PURPLE_BG   = "EDE9FE"
PINK_BG     = "FCE7F3"
AMBER_BG    = "FEF3C7"
GREY_BG     = "F1F5F9"
GREEN_FG    = "15803D"
PURPLE_FG   = "6D28D9"
PINK_FG     = "BE185D"
AMBER_FG    = "92400E"

DB_COLOURS = {
    "Foraminifera": (PURPLE_BG, PURPLE_FG),
    "Ostracoda":    (PINK_BG,   PINK_FG),
    "Diatoms":      (GREEN_BG,  GREEN_FG),
}


def _thin_border():
    s = Side(style="thin", color="D0D9E4")
    return Border(left=s, right=s, top=s, bottom=s)


# ------------------------------------------------------------------
# Instructions sheet
# ------------------------------------------------------------------

def _make_instructions(wb: openpyxl.Workbook, stats: dict):
    ws = wb.active
    ws.title = "Instructions"
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 2
    ws.column_dimensions["B"].width = 60
    ws.column_dimensions["C"].width = 30

    title_font  = Font(name="Calibri", size=16, bold=True, color=NAVY)
    head_font   = Font(name="Calibri", size=11, bold=True, color=NAVY)
    body_font   = Font(name="Calibri", size=10)
    step_font   = Font(name="Calibri", size=10, bold=True)
    muted_font  = Font(name="Calibri", size=9, color="64748B")
    title_fill  = PatternFill("solid", fgColor=NAVY)
    head_fill   = PatternFill("solid", fgColor=LIGHT_BLUE)

    def row(r, b_col, text, font=None, fill=None, merge_to="C", height=None, wrap=False):
        cell = ws.cell(row=r, column=2, value=text)
        cell.font = font or body_font
        if fill:
            for c in range(2, 4):
                ws.cell(row=r, column=c).fill = fill
        if merge_to:
            ws.merge_cells(f"B{r}:{merge_to}{r}")
        if height:
            ws.row_dimensions[r].height = height
        if wrap:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
        return cell

    # ── Title block ──────────────────────────────────────────────
    ws.row_dimensions[1].height = 10
    ws.row_dimensions[2].height = 40
    c = ws.cell(row=2, column=2,
                value="Ellis & Messina Micropaleontology Database")
    c.font = Font(name="Calibri", size=18, bold=True, color=WHITE)
    c.fill = PatternFill("solid", fgColor=NAVY)
    c.alignment = Alignment(vertical="center")
    for col in range(2, 4):
        ws.cell(row=2, column=col).fill = PatternFill("solid", fgColor=NAVY)
    ws.merge_cells("B2:C2")

    ws.row_dimensions[3].height = 20
    total_count = int(stats.get('total_count', 0) or 0)
    c3 = ws.cell(row=3, column=2,
                 value=f"Offline reference database  ·  "
                       f"{total_count:,} records  ·  "
                       f"Build date: {stats.get('build_date', '')[:10]}")
    c3.font = Font(name="Calibri", size=10, color="A8C4E8")
    c3.fill = PatternFill("solid", fgColor=NAVY)
    ws.merge_cells("B3:C3")

    ws.row_dimensions[4].height = 12

    # ── Database counts ───────────────────────────────────────────
    row(5, "B", "DATABASES IN THIS FILE", head_font, head_fill, height=20)
    counts = [
        ("Foraminifera", int(stats.get("foraminifera_count", 0) or 0)),
        ("Ostracoda",    int(stats.get("ostracoda_count", 0) or 0)),
        ("Diatoms",      int(stats.get("diatoms_count", 0) or 0)),
    ]
    for i, (db, cnt) in enumerate(counts, start=6):
        bg, fg = DB_COLOURS.get(db, (GREY_BG, NAVY))
        ws.row_dimensions[i].height = 16
        c = ws.cell(row=i, column=2, value=f"  {db}: {cnt:,} records")
        c.font = Font(name="Calibri", size=10, bold=True, color=fg)
        c.fill = PatternFill("solid", fgColor=bg)
        ws.merge_cells(f"B{i}:C{i}")

    ws.row_dimensions[9].height = 12

    # ── How to search ─────────────────────────────────────────────
    row(10, "B", "HOW TO SEARCH", head_font, head_fill, height=22)

    steps = [
        ("1", "Go to the  \"Database\"  sheet  (tab at the bottom of the screen)."),
        ("2", "The header row has drop-down arrows on every column."),
        ("3", "To search by taxon name:"),
        ("",  "   • Click the arrow on the  Taxon Name  column header"),
        ("",  "   • In the search box that appears, type part of the name (e.g.  Triloculina)"),
        ("",  "   • Click OK — only matching rows appear"),
        ("4", "To search across ALL columns at once:  press  Ctrl + F  and type your term."),
        ("5", "To filter by database (Foraminifera / Ostracoda / Diatoms):"),
        ("",  "   • Click the arrow on the  Database  column and check/uncheck as needed"),
        ("6", "To filter by year range:"),
        ("",  "   • Click the arrow on the  Year  column → 'Number Filters' → 'Between'"),
        ("7", "To remove all filters and see every record:"),
        ("",  "   • Click  Data  tab → Clear  (or press  Alt+A, C  on Windows)"),
        ("8", "To open a PDF: the  PDF Path  column shows the file location on disk."),
        ("",  "   Copy the path and paste into Windows Explorer, or navigate to"),
        ("",  "   the  downloads\\Foraminifera\\  (etc.) folder on your USB drive."),
    ]

    r = 11
    for step, text in steps:
        ws.row_dimensions[r].height = 16 if step else 14
        c_step = ws.cell(row=r, column=2, value=step)
        c_step.font = step_font if step else body_font
        c_text = ws.cell(row=r, column=3, value=text)
        c_text.font = body_font
        c_text.alignment = Alignment(wrap_text=True)
        r += 1

    ws.row_dimensions[r].height = 12
    r += 1

    # ── Columns explained ─────────────────────────────────────────
    row(r, "B", "COLUMN GUIDE", head_font, head_fill, height=22)
    r += 1

    col_guide = [
        ("Taxon Name",   "Full scientific name as it appears in Ellis & Messina"),
        ("Author",       "Taxonomic author(s)"),
        ("Year",         "Year of original description"),
        ("Database",     "Source: Foraminifera, Ostracoda, or Diatoms"),
        ("PDF",          "Y = PDF is downloaded and available;  N = not available"),
        ("PDF Path",     "Relative path to the PDF from the root folder of this system"),
        ("Record ID",    "Unique ID within the Ellis & Messina source database"),
        ("E&M URL",      "Direct link to the online record (requires internet)"),
    ]
    for cname, cdesc in col_guide:
        ws.row_dimensions[r].height = 16
        ws.cell(row=r, column=2, value=cname).font = Font(name="Calibri", size=10, bold=True)
        ws.cell(row=r, column=3, value=cdesc).font = body_font
        r += 1

    ws.row_dimensions[r].height = 12
    r += 1

    # ── Tips ──────────────────────────────────────────────────────
    row(r, "B", "TIPS", head_font, head_fill, height=22)
    r += 1
    tips = [
        "Wildcards: Excel filter search boxes support wildcards.  "
        "Use * to match anything, e.g.  *plicata  finds all names ending in 'plicata'.",
        "Sort: Click any column header to sort A→Z or Z→A.",
        "Freeze panes: The header row is already frozen — it stays visible as you scroll.",
        "Large dataset: This file has 80,000+ rows. Excel may take a few seconds to filter.",
        "Offline: This file works completely offline. No internet connection is needed.",
    ]
    for tip in tips:
        ws.row_dimensions[r].height = 30
        c = ws.cell(row=r, column=2, value=f"• {tip}")
        c.font = body_font
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(f"B{r}:C{r}")
        r += 1

    ws.row_dimensions[r].height = 12
    r += 1

    # ── Footer ───────────────────────────────────────────────────
    c = ws.cell(row=r, column=2,
                value="Ellis & Messina Catalogue of Foraminifera, Ostracoda, and Diatoms  "
                      "·  micropress.org  ·  Exported with Ellis_Messina offline tool")
    c.font = muted_font
    ws.merge_cells(f"B{r}:C{r}")

    ws.sheet_view.tabSelected = True


# ------------------------------------------------------------------
# Database sheet
# ------------------------------------------------------------------

COLUMNS = [
    ("Taxon Name",  "taxon_name",     42, True),   # (header, sql_col, width, italic_data)
    ("Author",      "author",         22, False),
    ("Year",        "year",            8, False),
    ("Database",    "database",       14, False),
    ("PDF",         "pdf_downloaded",  6, False),
    ("PDF Path",    "pdf_path",       50, False),
    ("Record ID",   "record_id",      12, False),
    ("E&M URL",     "original_url",   20, False),
]


def _make_database_sheet(wb: openpyxl.Workbook, rows: list, total: int):
    ws = wb.create_sheet("Database")
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A2"    # freeze header row

    # Column widths
    for i, (_, _, width, _) in enumerate(COLUMNS, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width

    # Header row styles
    header_font  = Font(name="Calibri", size=10, bold=True, color=WHITE)
    header_fill  = PatternFill("solid", fgColor=NAVY)
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 26

    for col_idx, (header, _, _, _) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    # AutoFilter on the full range
    last_col = get_column_letter(len(COLUMNS))
    ws.auto_filter.ref = f"A1:{last_col}{total + 1}"

    # Data rows
    body_font_normal  = Font(name="Calibri", size=10)
    body_font_italic  = Font(name="Calibri", size=10, italic=True)
    center_align      = Alignment(horizontal="center", vertical="center")
    left_align        = Alignment(horizontal="left",   vertical="center")
    year_align        = Alignment(horizontal="center", vertical="center")

    db_fills = {
        "Foraminifera": PatternFill("solid", fgColor="F5F3FF"),
        "Ostracoda":    PatternFill("solid", fgColor="FFF0F8"),
        "Diatoms":      PatternFill("solid", fgColor="F0FDF4"),
    }
    db_fonts = {
        "Foraminifera": Font(name="Calibri", size=10, bold=True, color=PURPLE_FG),
        "Ostracoda":    Font(name="Calibri", size=10, bold=True, color=PINK_FG),
        "Diatoms":      Font(name="Calibri", size=10, bold=True, color=GREEN_FG),
    }

    for row_idx, record in enumerate(rows, start=2):
        db_name = record[3] or ""
        alt_fill = PatternFill("solid", fgColor="F8FAFC") if row_idx % 2 == 0 else None

        for col_idx, (_, sql_col, _, is_italic) in enumerate(COLUMNS, start=1):
            # Map sql_col name to record tuple index
            val_map = {
                "taxon_name":     record[0],
                "author":         record[1],
                "year":           record[2],
                "database":       record[3],
                "pdf_downloaded": record[4],
                "pdf_path":       record[5],
                "record_id":      record[6],
                "original_url":   record[7],
            }
            value = val_map.get(sql_col)

            # Transform values
            if sql_col == "pdf_downloaded":
                value = "Y" if value else "N"
            elif sql_col == "year" and not value:
                value = ""

            cell = ws.cell(row=row_idx, column=col_idx, value=value)

            # Font
            if sql_col == "database" and db_name in db_fonts:
                cell.font = db_fonts[db_name]
            elif is_italic:
                cell.font = body_font_italic
            else:
                cell.font = body_font_normal

            # Alignment
            if sql_col in ("year", "pdf_downloaded", "record_id"):
                cell.alignment = center_align
            else:
                cell.alignment = left_align

            # Row shading (alternating)
            if alt_fill and sql_col != "database":
                cell.fill = alt_fill

        ws.row_dimensions[row_idx].height = 15

    # Add the Table (enables structured reference + nicer filter UI)
    tab = Table(
        displayName="EllisMessinaDB",
        ref=f"A1:{last_col}{total + 1}",
    )
    style = TableStyleInfo(
        name="TableStyleMedium2",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )
    tab.tableStyleInfo = style
    ws.add_table(tab)


# ------------------------------------------------------------------
# Main export function
# ------------------------------------------------------------------

def export(
    output_path: Path,
    database_filter: str = "All",
    pdf_only: bool = False,
    verbose: bool = True,
) -> dict:
    def log(msg):
        if verbose:
            print(msg)

    if not DB_PATH.exists():
        print(f"ERROR: Database not found at {DB_PATH}")
        print("Run:  python build_database.py")
        sys.exit(1)

    t0 = time.time()

    # ── Fetch records from SQLite ────────────────────────────────
    log("Reading records from database...")
    conn = sqlite3.connect(str(DB_PATH))

    where_clauses = []
    params = []
    if database_filter != "All":
        where_clauses.append("database = ?")
        params.append(database_filter)
    if pdf_only:
        where_clauses.append("pdf_downloaded = 1")

    where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

    total = conn.execute(
        f"SELECT COUNT(*) FROM records {where_sql}", params
    ).fetchone()[0]

    log(f"  {total:,} records selected")

    rows_raw = conn.execute(
        f"""SELECT
               taxon_name, author, year, database,
               pdf_downloaded, pdf_path, record_id, original_url
            FROM records
            {where_sql}
            ORDER BY taxon_name COLLATE NOCASE""",
        params,
    ).fetchall()

    # Fetch stats for the instructions sheet
    stats_raw = conn.execute("SELECT key, value FROM db_meta").fetchall()
    stats = {k: v for k, v in stats_raw}
    conn.close()

    # ── Build workbook ───────────────────────────────────────────
    log("Building Excel workbook (this may take 60–120 seconds for 83K rows)...")
    wb = openpyxl.Workbook()

    _make_instructions(wb, stats)
    _make_database_sheet(wb, rows_raw, total)

    # Make "Instructions" the active sheet when file opens
    wb.active = wb["Instructions"]

    # ── Save ─────────────────────────────────────────────────────
    log(f"Saving to {output_path} ...")
    wb.save(str(output_path))
    elapsed = time.time() - t0

    size_mb = output_path.stat().st_size / 1_048_576
    log(f"\nDone: {total:,} records → {output_path.name}  "
        f"({size_mb:.1f} MB, {elapsed:.0f}s)")

    return {"total": total, "output": output_path, "elapsed": elapsed, "size_mb": size_mb}


# ------------------------------------------------------------------
# CLI
# ------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Export Ellis & Messina SQLite DB to a searchable Excel file",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python tools/export_to_excel.py
  python tools/export_to_excel.py --output Desktop/EllisMessinaForam.xlsx --database Foraminifera
  python tools/export_to_excel.py --pdf-only
        """,
    )
    parser.add_argument("--output", "-o", type=Path,
                        default=PROJECT_ROOT / "Ellis_Messina_Database.xlsx",
                        help="Output .xlsx file path")
    parser.add_argument("--database", "-d",
                        choices=["All", "Foraminifera", "Ostracoda", "Diatoms"],
                        default="All",
                        help="Export only one database (default: All)")
    parser.add_argument("--pdf-only", action="store_true",
                        help="Only include records that have a PDF downloaded")
    parser.add_argument("--quiet", action="store_true",
                        help="Suppress progress output")
    args = parser.parse_args()

    output = Path(args.output).with_suffix(".xlsx")
    result = export(
        output_path=output,
        database_filter=args.database,
        pdf_only=args.pdf_only,
        verbose=not args.quiet,
    )

    print()
    print("The Excel file is ready to share.")
    print(f"  File:    {result['output']}")
    print(f"  Records: {result['total']:,}")
    print(f"  Size:    {result['size_mb']:.1f} MB")
    print()
    print("To search: open the file → go to the 'Database' sheet")
    print("  → click the dropdown arrows on column headers to filter.")
