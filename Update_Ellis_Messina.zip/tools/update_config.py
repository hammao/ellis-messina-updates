"""
Configuration for database update checking
"""
import os

# Email notification settings (optional)
EMAIL_ENABLED = False
SMTP_SERVER = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
SMTP_PORT = int(os.getenv('SMTP_PORT', '587'))
SMTP_USERNAME = os.getenv('SMTP_USERNAME', '')
SMTP_PASSWORD = os.getenv('SMTP_PASSWORD', '')
EMAIL_FROM = os.getenv('EMAIL_FROM', '')
EMAIL_TO = os.getenv('EMAIL_TO', '')

# Update check settings
CHECK_FORAMINIFERA = True
CHECK_OSTRACODA = True
CHECK_DIATOMS = True

# Notification preferences
NOTIFY_CONSOLE = True
NOTIFY_FILE = True
NOTIFY_EMAIL = False  # Set to True if email is configured

# Update report directory
UPDATE_REPORT_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'updates')

