# Building the Standalone Search Application

This guide explains how to build the standalone executable for the Ellis & Messina Search application.

## Prerequisites

1. **Python 3.7+** installed on your system
2. **All dependencies** installed:
   ```bash
   pip install -r requirements.txt
   ```
   This includes:
   - tkinter (usually included with Python)
   - fuzzywuzzy
   - python-Levenshtein
   - pyinstaller

## Building on Mac/Linux

1. Open Terminal in the project directory

2. Make the build script executable (if not already):
   ```bash
   chmod +x build_standalone.sh
   ```

3. Run the build script:
   ```bash
   ./build_standalone.sh
   ```

4. The executable will be created in the `dist/` folder:
   - `dist/EllisMessinaSearch` (Mac/Linux executable)

## Building on Windows

1. Open Command Prompt or PowerShell in the project directory

2. Run the build script:
   ```batch
   build_standalone.bat
   ```

3. The executable will be created in the `dist/` folder:
   - `dist/EllisMessinaSearch.exe` (Windows executable)

## Manual Build (Advanced)

If you need more control over the build process:

### Mac/Linux
```bash
pyinstaller \
    --name "EllisMessinaSearch" \
    --onefile \
    --windowed \
    --add-data "downloads:downloads" \
    standalone_search_app.py
```

### Windows
```batch
pyinstaller ^
    --name "EllisMessinaSearch" ^
    --onefile ^
    --windowed ^
    --add-data "downloads;downloads" ^
    standalone_search_app.py
```

## Build Options Explained

- `--name "EllisMessinaSearch"`: Name of the output executable
- `--onefile`: Create a single executable file (easier to distribute)
- `--windowed`: Don't show a console window (GUI only)
- `--add-data "downloads:downloads"`: Include the downloads folder in the executable

## Creating a Mac .app Bundle

To create a proper Mac application bundle:

```bash
pyinstaller \
    --name "EllisMessinaSearch" \
    --windowed \
    --add-data "downloads:downloads" \
    --icon=icon.icns \
    standalone_search_app.py
```

Note: You'll need to create an `.icns` icon file first, or omit the `--icon` option.

## Distribution

### What to Include

When distributing the application, include:

1. **The executable file** (`EllisMessinaSearch` or `EllisMessinaSearch.exe`)
2. **The `downloads/` folder** (with all PDFs and metadata)

### Recommended Structure

```
EllisMessinaSearch_Package/
├── EllisMessinaSearch          (or .exe on Windows)
├── README.txt                  (instructions for users)
└── downloads/
    ├── metadata/
    │   ├── foraminifera_index.csv
    │   ├── ostracoda_index.csv
    │   └── diatoms_index.csv
    ├── Foraminifera/
    ├── Ostracoda/
    └── Diatoms/
```

### Creating a ZIP Archive

**Mac/Linux:**
```bash
zip -r EllisMessinaSearch_Mac.zip EllisMessinaSearch downloads/
```

**Windows:**
```powershell
Compress-Archive -Path EllisMessinaSearch.exe,downloads -DestinationPath EllisMessinaSearch_Windows.zip
```

## Troubleshooting Build Issues

### "PyInstaller not found"

Install PyInstaller:
```bash
pip install pyinstaller
```

### "Module not found" errors

Ensure all dependencies are installed:
```bash
pip install -r requirements.txt
```

### Large executable size

The executable includes Python and all dependencies, so it will be 50-100MB. This is normal.

### "Downloads folder not found" at runtime

The `--add-data` option embeds the downloads folder, but the application may need to extract it at runtime. If you encounter issues:

1. Place the `downloads/` folder next to the executable
2. Or modify the build to use `--add-data` with proper path handling

### Antivirus warnings (Windows)

Some antivirus software may flag PyInstaller executables as suspicious. This is a false positive. You can:
- Add an exception in your antivirus
- Sign the executable with a code signing certificate (for distribution)

## Testing the Build

After building, test the executable:

1. **Mac/Linux:**
   ```bash
   ./dist/EllisMessinaSearch
   ```

2. **Windows:**
   ```batch
   dist\EllisMessinaSearch.exe
   ```

3. Verify:
   - Application starts without errors
   - Can load metadata from CSV files
   - Search functionality works
   - PDF files can be opened

## Advanced: Custom Icon

To add a custom icon:

1. Create an icon file:
   - **Mac**: `.icns` format
   - **Windows**: `.ico` format
   - **Linux**: `.png` or `.ico` format

2. Add to build command:
   ```bash
   pyinstaller --icon=icon.icns ... (other options)
   ```

## Notes

- The first run of the executable may be slower as PyInstaller extracts files
- The executable is platform-specific (Mac executable won't run on Windows, etc.)
- For cross-platform distribution, build separate executables for each platform
- The `downloads/` folder can be large (several GB). Consider compressing it separately or providing download instructions.

