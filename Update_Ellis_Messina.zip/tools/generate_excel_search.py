"""
Generate Excel search form with VBA macro for searching Ellis & Messina PDF database
"""
import os
import sys
import csv
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.hyperlink import Hyperlink

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

def create_excel_search_form():
    """Create Excel workbook with search interface and VBA macro"""
    
    # Paths
    metadata_dir = Path(__file__).parent.parent / "downloads" / "metadata"
    output_file = Path(__file__).parent.parent / "Ellis_Messina_Search.xlsm"
    
    # Create workbook
    wb = Workbook()
    
    # Rename default sheet to Search
    search_sheet = wb.active
    search_sheet.title = "Search"
    
    # Create Data sheet (will be hidden)
    data_sheet = wb.create_sheet("Data")
    
    # Load all CSV files
    all_records = []
    csv_files = list(metadata_dir.glob("*_index.csv"))
    
    print(f"Found {len(csv_files)} CSV files")
    
    for csv_file in csv_files:
        database = csv_file.stem.replace("_index", "")
        print(f"Loading {database} from {csv_file.name}...")
        
        try:
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # Skip records with empty taxon_name AND empty genus (invalid records)
                    taxon_name = str(row.get('taxon_name', '')).strip()
                    genus = str(row.get('genus', '')).strip()
                    if not taxon_name and not genus:
                        continue
                    
                    # Check if PDF was downloaded or has PDF path
                    pdf_path = row.get('pdf_path', '') or ''
                    pdf_paths = row.get('pdf_paths', '')
                    
                    # Handle pdf_paths if it's a string representation of a list
                    if pdf_paths and not pdf_path:
                        try:
                            import ast
                            if isinstance(pdf_paths, str) and pdf_paths.startswith('['):
                                paths_list = ast.literal_eval(pdf_paths)
                                if paths_list and isinstance(paths_list, list):
                                    pdf_path = paths_list[0] if paths_list else ''
                        except:
                            pass
                    
                    pdf_downloaded = str(row.get('pdf_downloaded', '')).lower()
                    
                    # Skip records where pdf_downloaded is False AND pdf_path is empty
                    if pdf_downloaded not in ('true', '1', 'yes') and not pdf_path:
                        continue
                    
                    # Validate PDF path exists before adding
                    if pdf_path:
                        pdf_file = Path(__file__).parent.parent / pdf_path
                        if not pdf_file.exists():
                            # Skip if PDF doesn't exist
                            continue
                    
                    # Add database name
                    row['database'] = database.capitalize()
                    all_records.append(row)
        except Exception as e:
            print(f"Error loading {csv_file}: {e}")
    
    print(f"Loaded {len(all_records)} records with PDFs")
    
    if not all_records:
        print("No records found! Make sure CSV files exist in downloads/metadata/")
        return
    
    # Write data to Data sheet
    if all_records:
        fieldnames = list(all_records[0].keys())
        # Reorder columns for better readability
        preferred_order = ['database', 'taxon_name', 'genus', 'species', 'subgenus', 
                          'subspecies', 'variety', 'author', 'year', 'record_id', 
                          'pdf_path', 'pdf_paths', 'original_url']
        # Add remaining fields
        for field in fieldnames:
            if field not in preferred_order:
                preferred_order.append(field)
        
        # Write header
        for col_idx, field in enumerate(preferred_order, 1):
            cell = data_sheet.cell(row=1, column=col_idx)
            cell.value = field
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
            cell.font = Font(bold=True, color="FFFFFF")
        
        # Write data
        for row_idx, record in enumerate(all_records, 2):
            for col_idx, field in enumerate(preferred_order, 1):
                value = record.get(field, '')
                # Handle list values (like pdf_paths)
                if isinstance(value, str) and value.startswith('['):
                    # Try to extract first path from list
                    import ast
                    try:
                        value_list = ast.literal_eval(value)
                        if value_list:
                            value = value_list[0] if isinstance(value_list[0], str) else str(value_list[0])
                        else:
                            value = ''
                    except:
                        pass
                
                cell = data_sheet.cell(row=row_idx, column=col_idx)
                
                # Handle value - Excel has cell value limits
                if value:
                    # Truncate very long values (Excel limit is 32,767 characters)
                    str_value = str(value)
                    if len(str_value) > 32767:
                        str_value = str_value[:32700] + "... (truncated)"
                    
                    # Clean value - remove None, convert lists/dicts to strings
                    if isinstance(value, (list, dict)):
                        import json
                        try:
                            str_value = json.dumps(value)[:1000]  # Limit JSON strings
                        except:
                            str_value = str(value)[:1000]
                    
                    cell.value = str_value[:32767]  # Excel cell limit
                else:
                    cell.value = ""
                
                # Make PDF path a hyperlink
                if field == 'pdf_path' and value:
                    try:
                        pdf_path = Path(__file__).parent.parent / str(value)
                        if pdf_path.exists():
                            # Use relative path for hyperlink
                            rel_path = pdf_path.relative_to(Path(__file__).parent.parent)
                            cell.hyperlink = f"file:///{pdf_path.absolute()}"
                            cell.font = Font(color="0000FF", underline="single")
                    except Exception as e:
                        # Skip hyperlink if there's an error
                        pass
        
        # Auto-adjust column widths (limit to avoid issues)
        for col_idx, field in enumerate(preferred_order, 1):
            max_length = min(len(str(field)), 50)
            # Sample rows to determine width (don't check all rows for performance)
            sample_size = min(1000, len(all_records))
            for row_idx in range(2, min(sample_size + 2, len(all_records) + 2)):
                try:
                    cell_value = data_sheet.cell(row=row_idx, column=col_idx).value
                    if cell_value:
                        max_length = max(max_length, min(len(str(cell_value)), 100))
                except:
                    pass
            data_sheet.column_dimensions[get_column_letter(col_idx)].width = min(max_length + 2, 50)
    
    # Hide Data sheet
    data_sheet.sheet_state = 'hidden'
    
    # Create Search Interface
    setup_search_interface(search_sheet, len(all_records))
    
    # Add VBA macro
    add_vba_macro(wb, output_file)
    
    # Save workbook as .xlsx first (openpyxl doesn't support .xlsm directly)
    # User will need to save as .xlsm after adding VBA macro
    xlsx_file = output_file.with_suffix('.xlsx')
    wb.save(xlsx_file)
    
    print(f"\nExcel search form created: {xlsx_file}")
    print(f"Total records: {len(all_records)}")
    print(f"Databases: {', '.join(set(r.get('database', '') for r in all_records))}")
    print(f"\nIMPORTANT: To enable macros:")
    print(f"1. Open {xlsx_file.name} in Excel")
    print(f"2. Add the VBA macro (see instructions below)")
    print(f"3. Save As > Excel Macro-Enabled Workbook (.xlsm)")
    print(f"4. Name it: {output_file.name}")

def setup_search_interface(sheet, total_records):
    """Setup the search interface sheet"""
    
    # Title
    sheet['A1'] = "Ellis & Messina PDF Database Search"
    sheet['A1'].font = Font(size=16, bold=True)
    sheet.merge_cells('A1:F1')
    
    # Search section
    sheet['A3'] = "Search Options"
    sheet['A3'].font = Font(size=12, bold=True)
    
    sheet['A4'] = "Search Term:"
    sheet['B4'] = ""  # Input cell
    sheet['B4'].fill = PatternFill(start_color="FFFF99", end_color="FFFF99", fill_type="solid")
    
    sheet['A5'] = "Database Filter:"
    sheet['B5'] = "All"  # Dropdown: All, Foraminifera, Ostracoda, Diatoms
    sheet['B5'].fill = PatternFill(start_color="E7E6E6", end_color="E7E6E6", fill_type="solid")
    
    sheet['A6'] = "Fuzzy Match:"
    sheet['B6'] = "Yes"  # Yes/No
    sheet['B6'].fill = PatternFill(start_color="E7E6E6", end_color="E7E6E6", fill_type="solid")
    
    sheet['A7'] = "Search Button:"
    button_cell = sheet['B7']
    button_cell.value = "🔍 Search"
    button_cell.fill = PatternFill(start_color="4F81BD", end_color="4F81BD", fill_type="solid")
    button_cell.font = Font(bold=True, color="FFFFFF")
    button_cell.alignment = Alignment(horizontal="center")
    
    # Results section
    sheet['A9'] = f"Results (Total Records: {total_records})"
    sheet['A9'].font = Font(size=12, bold=True)
    
    # Results header
    headers = ["Taxon Name", "Genus", "Species", "Author", "Year", "Record ID", "Database", "PDF Link"]
    for col_idx, header in enumerate(headers, 1):
        cell = sheet.cell(row=10, column=col_idx)
        cell.value = header
        cell.font = Font(bold=True)
        cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        cell.font = Font(bold=True, color="FFFFFF")
        cell.alignment = Alignment(horizontal="center", vertical="center")
    
    # Format columns
    sheet.column_dimensions['A'].width = 30
    sheet.column_dimensions['B'].width = 20
    sheet.column_dimensions['C'].width = 20
    sheet.column_dimensions['D'].width = 20
    sheet.column_dimensions['E'].width = 10
    sheet.column_dimensions['F'].width = 12
    sheet.column_dimensions['G'].width = 15
    sheet.column_dimensions['H'].width = 50
    
    # Freeze panes
    sheet.freeze_panes = 'A11'

def add_vba_macro(wb, output_file):
    """Save VBA macro instructions"""
    vba_file = Path(__file__).parent / "search_macro.vba"
    print(f"\nVBA macro file created: {vba_file}")
    print("\nTo add the VBA macro to Excel:")
    print("1. Open the generated Excel file: " + str(output_file))
    print("2. Press Alt+F11 to open VBA editor")
    print("3. Insert > Module")
    print("4. Open the file: " + str(vba_file))
    print("5. Copy all code and paste into the module")
    print("6. Right-click cell B7 (Search button) > Assign Macro > SearchDatabase")
    print("7. Save the file (Ctrl+S)")

if __name__ == "__main__":
    try:
        create_excel_search_form()
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

