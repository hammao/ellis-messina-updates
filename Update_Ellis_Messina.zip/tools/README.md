# Ellis & Messina Database Tools

## Excel Search Form

### Generate Excel Search Form

Run the generator to create an Excel file with searchable database:

```bash
python3 tools/generate_excel_search.py
```

This creates:
- `Ellis_Messina_Search.xlsm` - Excel macro-enabled workbook
- `tools/search_macro.vba` - VBA macro code

### Setup Excel Search Form

1. Open `Ellis_Messina_Search.xlsm` in Excel
2. Press `Alt+F11` to open VBA editor
3. Insert > Module
4. Open `tools/search_macro.vba` and copy all code
5. Paste into the module
6. Close VBA editor
7. Right-click cell B7 (Search button) > Assign Macro > SearchDatabase
8. Save the file

### Using the Search Form

1. Enter search term in cell B4 (genus, species, or taxon name)
2. Select database filter in B5 (All, Foraminifera, Ostracoda, Diatoms)
3. Set fuzzy match in B6 (Yes/No)
4. Click the Search button (B7) or run the macro
5. Results appear in rows 11+
6. Click "Open PDF" links to open PDFs

## Update Checker

### Manual Update Check

Check for new records and download them:

```bash
python3 tools/check_updates.py
```

### Scheduled Updates

Run updates automatically on a schedule:

```bash
# Install schedule library first
pip install schedule

# Run scheduled updates (daily at 2 AM)
python3 update_scheduler.py --mode scheduled

# Run scheduled updates at custom time
python3 update_scheduler.py --mode scheduled --time 03:00
```

### Configuration

Edit `tools/update_config.py` to configure:
- Which databases to check
- Notification preferences (console, file, email)
- Email settings (optional)

### Email Notifications

To enable email notifications:

1. Set `EMAIL_ENABLED = True` in `tools/update_config.py`
2. Set environment variables:
   ```bash
   export SMTP_SERVER=smtp.gmail.com
   export SMTP_PORT=587
   export SMTP_USERNAME=your_email@gmail.com
   export SMTP_PASSWORD=your_app_password
   export EMAIL_FROM=your_email@gmail.com
   export EMAIL_TO=recipient@example.com
   ```

### Update Reports

Update reports are saved to `updates/new_records_YYYY-MM-DD.txt`

## Files

- `generate_excel_search.py` - Excel form generator
- `search_macro.vba` - VBA search macro
- `check_updates.py` - Update checker script
- `update_config.py` - Update configuration
- `send_email.py` - Email notification module
- `update_scheduler.py` - Scheduled update runner

