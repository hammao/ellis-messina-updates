Attribute VB_Name = "Module1"
Option Explicit

' Fuzzy search threshold (0-100, higher = more strict)
Const FUZZY_THRESHOLD As Integer = 70

' Main search function - called from Search button
Sub SearchDatabase()
    Dim searchTerm As String
    Dim dbFilter As String
    Dim useFuzzy As Boolean
    Dim dataSheet As Worksheet
    Dim searchSheet As Worksheet
    Dim lastRow As Long
    Dim i As Long
    Dim resultRow As Long
    Dim matchFound As Boolean
    
    ' Get search parameters
    Set searchSheet = ThisWorkbook.Sheets("Search")
    searchTerm = Trim(searchSheet.Range("B4").Value)
    dbFilter = Trim(searchSheet.Range("B5").Value)
    useFuzzy = (Trim(searchSheet.Range("B6").Value) = "Yes")
    
    ' Clear previous results
    searchSheet.Range("A11:H1000").ClearContents
    
    If searchTerm = "" Then
        MsgBox "Please enter a search term", vbInformation
        Exit Sub
    End If
    
    ' Get data sheet
    Set dataSheet = ThisWorkbook.Sheets("Data")
    lastRow = dataSheet.Cells(dataSheet.Rows.Count, 1).End(xlUp).Row
    
    ' Find column indices
    Dim dbCol As Integer, taxonCol As Integer, genusCol As Integer
    Dim speciesCol As Integer, authorCol As Integer, yearCol As Integer
    Dim recordIdCol As Integer, pdfPathCol As Integer
    
    dbCol = FindColumn(dataSheet, "database")
    taxonCol = FindColumn(dataSheet, "taxon_name")
    genusCol = FindColumn(dataSheet, "genus")
    speciesCol = FindColumn(dataSheet, "species")
    authorCol = FindColumn(dataSheet, "author")
    yearCol = FindColumn(dataSheet, "year")
    recordIdCol = FindColumn(dataSheet, "record_id")
    pdfPathCol = FindColumn(dataSheet, "pdf_path")
    
    ' Error handling for missing columns
    If dbCol = 0 Or taxonCol = 0 Or pdfPathCol = 0 Then
        MsgBox "Error: Required columns not found in Data sheet. Please regenerate the Excel file.", vbCritical
        Exit Sub
    End If
    
    resultRow = 11
    searchTerm = LCase(searchTerm)
    
    ' Search through data
    For i = 2 To lastRow
        ' Check database filter
        If dbFilter <> "All" Then
            Dim dbValue As Variant
            dbValue = dataSheet.Cells(i, dbCol).Value
            If IsNull(dbValue) Or dbValue = "" Then
                dbValue = ""
            Else
                dbValue = LCase(Trim(CStr(dbValue)))
            End If
            If dbValue <> LCase(dbFilter) Then
                GoTo NextRow
            End If
        End If
        
        ' Get searchable fields with null handling
        Dim taxonName As String, genus As String, species As String, author As String
        Dim cellValue As Variant
        
        cellValue = dataSheet.Cells(i, taxonCol).Value
        If IsNull(cellValue) Or cellValue = "" Then
            taxonName = ""
        Else
            taxonName = LCase(Trim(CStr(cellValue)))
        End If
        
        If genusCol > 0 Then
            cellValue = dataSheet.Cells(i, genusCol).Value
            If IsNull(cellValue) Or cellValue = "" Then
                genus = ""
            Else
                genus = LCase(Trim(CStr(cellValue)))
            End If
        Else
            genus = ""
        End If
        
        If speciesCol > 0 Then
            cellValue = dataSheet.Cells(i, speciesCol).Value
            If IsNull(cellValue) Or cellValue = "" Then
                species = ""
            Else
                species = LCase(Trim(CStr(cellValue)))
            End If
        Else
            species = ""
        End If
        
        If authorCol > 0 Then
            cellValue = dataSheet.Cells(i, authorCol).Value
            If IsNull(cellValue) Or cellValue = "" Then
                author = ""
            Else
                author = LCase(Trim(CStr(cellValue)))
            End If
        Else
            author = ""
        End If
        
        matchFound = False
        
        If useFuzzy Then
            ' Fuzzy matching
            If FuzzyMatch(searchTerm, taxonName) >= FUZZY_THRESHOLD Then matchFound = True
            If FuzzyMatch(searchTerm, genus) >= FUZZY_THRESHOLD Then matchFound = True
            If FuzzyMatch(searchTerm, species) >= FUZZY_THRESHOLD Then matchFound = True
            If FuzzyMatch(searchTerm, author) >= FUZZY_THRESHOLD Then matchFound = True
        Else
            ' Exact/partial matching
            If InStr(taxonName, searchTerm) > 0 Then matchFound = True
            If InStr(genus, searchTerm) > 0 Then matchFound = True
            If InStr(species, searchTerm) > 0 Then matchFound = True
            If InStr(author, searchTerm) > 0 Then matchFound = True
        End If
        
        If matchFound Then
            ' Write result with null handling
            cellValue = dataSheet.Cells(i, taxonCol).Value
            searchSheet.Cells(resultRow, 1).Value = IIf(IsNull(cellValue) Or cellValue = "", "", CStr(cellValue))
            
            If genusCol > 0 Then
                cellValue = dataSheet.Cells(i, genusCol).Value
                searchSheet.Cells(resultRow, 2).Value = IIf(IsNull(cellValue) Or cellValue = "", "", CStr(cellValue))
            End If
            
            If speciesCol > 0 Then
                cellValue = dataSheet.Cells(i, speciesCol).Value
                searchSheet.Cells(resultRow, 3).Value = IIf(IsNull(cellValue) Or cellValue = "", "", CStr(cellValue))
            End If
            
            If authorCol > 0 Then
                cellValue = dataSheet.Cells(i, authorCol).Value
                searchSheet.Cells(resultRow, 4).Value = IIf(IsNull(cellValue) Or cellValue = "", "", CStr(cellValue))
            End If
            
            If yearCol > 0 Then
                cellValue = dataSheet.Cells(i, yearCol).Value
                searchSheet.Cells(resultRow, 5).Value = IIf(IsNull(cellValue) Or cellValue = "", "", CStr(cellValue))
            End If
            
            If recordIdCol > 0 Then
                cellValue = dataSheet.Cells(i, recordIdCol).Value
                searchSheet.Cells(resultRow, 6).Value = IIf(IsNull(cellValue) Or cellValue = "", "", CStr(cellValue))
            End If
            
            cellValue = dataSheet.Cells(i, dbCol).Value
            searchSheet.Cells(resultRow, 7).Value = IIf(IsNull(cellValue) Or cellValue = "", "", CStr(cellValue))
            
            ' Add PDF link with improved path handling
            cellValue = dataSheet.Cells(i, pdfPathCol).Value
            Dim pdfPath As String
            If IsNull(cellValue) Or cellValue = "" Then
                pdfPath = ""
            Else
                pdfPath = CStr(cellValue)
            End If
            
            If pdfPath <> "" Then
                ' Convert relative path to absolute - handle both Windows and Mac paths
                Dim fullPath As String
                Dim pathSep As String
                pathSep = Application.PathSeparator
                
                ' Check if path is already absolute
                If Left(pdfPath, 1) = "/" Or Mid(pdfPath, 2, 1) = ":" Then
                    ' Unix absolute path or Windows absolute path
                    fullPath = pdfPath
                Else
                    ' Relative path - make it relative to workbook location
                    fullPath = ThisWorkbook.Path & pathSep & pdfPath
                End If
                
                ' Normalize path separators
                fullPath = Replace(fullPath, "/", pathSep)
                fullPath = Replace(fullPath, "\", pathSep)
                
                ' Remove duplicate separators
                Do While InStr(fullPath, pathSep & pathSep) > 0
                    fullPath = Replace(fullPath, pathSep & pathSep, pathSep)
                Loop
                
                searchSheet.Cells(resultRow, 8).Value = "Open PDF"
                On Error Resume Next
                searchSheet.Hyperlinks.Add Anchor:=searchSheet.Cells(resultRow, 8), Address:="file:///" & Replace(fullPath, pathSep, "/"), TextToDisplay:="Open PDF"
                On Error GoTo 0
                searchSheet.Cells(resultRow, 8).Font.Color = RGB(0, 0, 255)
                searchSheet.Cells(resultRow, 8).Font.Underline = xlUnderlineStyleSingle
            End If
            
            resultRow = resultRow + 1
            If resultRow > 1000 Then Exit For ' Limit results
        End If
        
NextRow:
    Next i
    
    If resultRow = 11 Then
        MsgBox "No matches found", vbInformation
    Else
        MsgBox "Found " & (resultRow - 11) & " results", vbInformation
    End If
End Sub

' Find column index by header name
Function FindColumn(sheet As Worksheet, headerName As String) As Integer
    Dim i As Integer
    Dim cellValue As Variant
    For i = 1 To 50
        cellValue = sheet.Cells(1, i).Value
        If Not IsNull(cellValue) And cellValue <> "" Then
            If LCase(Trim(CStr(cellValue))) = LCase(headerName) Then
                FindColumn = i
                Exit Function
            End If
        End If
    Next i
    FindColumn = 0
End Function

' Null/Empty value helper - replaced with inline checks for compatibility
Function SafeString(value As Variant, defaultValue As String) As String
    If IsNull(value) Or value = "" Or IsEmpty(value) Then
        SafeString = defaultValue
    Else
        SafeString = CStr(value)
    End If
End Function

' Simple fuzzy matching using character similarity
Function FuzzyMatch(str1 As String, str2 As String) As Integer
    If str1 = "" Or str2 = "" Then
        FuzzyMatch = 0
        Exit Function
    End If
    
    ' Exact match
    If str1 = str2 Then
        FuzzyMatch = 100
        Exit Function
    End If
    
    ' Substring matching
    If InStr(str2, str1) > 0 Or InStr(str1, str2) > 0 Then
        FuzzyMatch = 85
        Exit Function
    End If
    
    ' Character overlap similarity
    Dim matches As Integer
    Dim i As Integer
    Dim minLen As Integer
    minLen = Application.WorksheetFunction.Min(Len(str1), Len(str2))
    
    matches = 0
    For i = 1 To minLen
        If Mid(str1, i, 1) = Mid(str2, i, 1) Then
            matches = matches + 1
        End If
    Next i
    
    If minLen > 0 Then
        FuzzyMatch = (matches / minLen) * 100
    Else
        FuzzyMatch = 0
    End If
End Function

