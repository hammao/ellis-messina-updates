"""
Email notification module for update reports
"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from tools.update_config import *

def send_update_email(report: str, new_records_by_db: dict, download_results_by_db: dict):
    """Send update report via email"""
    if not EMAIL_ENABLED or not SMTP_USERNAME or not SMTP_PASSWORD:
        raise ValueError("Email not configured. Set EMAIL_ENABLED=True and provide SMTP credentials.")
    
    # Create message
    msg = MIMEMultipart()
    msg['From'] = EMAIL_FROM or SMTP_USERNAME
    msg['To'] = EMAIL_TO
    msg['Subject'] = f"Ellis & Messina Database Update - {len(sum(new_records_by_db.values(), []))} New Records"
    
    # Add body
    body = report
    msg.attach(MIMEText(body, 'plain'))
    
    # Send email
    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        text = msg.as_string()
        server.sendmail(msg['From'], msg['To'], text)
        server.quit()
        return True
    except Exception as e:
        raise Exception(f"Failed to send email: {str(e)}")

