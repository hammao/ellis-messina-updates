"""
app.py — Flask web application for the Ellis & Messina offline search interface.

Routes:
  GET /                          → main search page
  GET /api/search                → JSON search endpoint
  GET /api/suggest               → autocomplete suggestions
  GET /api/worms/<taxon_name>    → WoRMS taxonomy lookup (cached)
  GET /api/stats                 → database statistics
  GET /pdf/<record_id>/<database> → serve PDF inline for browser viewer
"""

import os
import re
import sqlite3
import sys
from pathlib import Path
import logging
from datetime import datetime

from flask import Flask, request, jsonify, render_template, send_file, abort

# Support running as a PyInstaller-frozen .exe
if getattr(sys, "frozen", False):
    # Bundled: templates/static are in _MEIPASS; DB is next to the .exe
    _BUNDLE_DIR = Path(sys._MEIPASS)
    PROJECT_ROOT = Path(sys.executable).parent.resolve()
    _TEMPLATE_DIR = _BUNDLE_DIR / "templates"
    _STATIC_DIR   = _BUNDLE_DIR / "static"
else:
    PROJECT_ROOT  = Path(__file__).parent.resolve()
    _TEMPLATE_DIR = PROJECT_ROOT / "templates"
    _STATIC_DIR   = PROJECT_ROOT / "static"

# ------------------------------------------------------------------
# PDF base path — configurable so PDFs can live on a USB drive or
# a different folder from the app.
#
# Resolution order (first match wins):
#   1. Environment variable:  EM_PDF_BASE=/path/to/downloads
#   2. Config file:           pdf_base.txt (one path per line, first valid)
#   3. Default:               PROJECT_ROOT  (relative paths in the database)
# ------------------------------------------------------------------
def _resolve_pdf_base() -> Path:
    env = os.environ.get("EM_PDF_BASE", "").strip()
    if env and Path(env).is_dir():
        return Path(env).resolve()

    cfg = PROJECT_ROOT / "pdf_base.txt"
    if cfg.exists():
        for line in cfg.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and Path(line).is_dir():
                return Path(line).resolve()

    return PROJECT_ROOT

PDF_BASE = _resolve_pdf_base()

app = Flask(
    __name__,
    template_folder=str(_TEMPLATE_DIR),
    static_folder=str(_STATIC_DIR),
)

@app.template_filter("format_number")
def format_number(value):
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError):
        return str(value)



# ------------------------------------------------------------------
# User access logging
# ------------------------------------------------------------------
_log_dir = PROJECT_ROOT / "logs"
_log_dir.mkdir(exist_ok=True)

_user_logger = logging.getLogger("user_access")
_user_logger.setLevel(logging.INFO)
_user_handler = logging.FileHandler(_log_dir / "user_access.log")
_user_handler.setFormatter(logging.Formatter("%(message)s"))
_user_logger.addHandler(_user_handler)


@app.after_request
def log_user_access(response):
    if request.path.startswith("/static/") or request.path == "/favicon.ico":
        return response
    user = request.headers.get("Cf-Access-Authenticated-User-Email", "anonymous")
    ip = request.headers.get("X-Real-IP", request.remote_addr)
    _user_logger.info(
        f"{datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} | {user} | "
        f"{request.method} {request.path} | {response.status_code} | {ip}"
    )
    return response

# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _parse_int(value, default=None):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


# ------------------------------------------------------------------
# Main page
# ------------------------------------------------------------------

def _read_version() -> str:
    try:
        return (PROJECT_ROOT / "version.txt").read_text(encoding="utf-8").strip()
    except Exception:
        return ""


@app.route("/")
def index():
    from search import get_stats
    try:
        meta = get_stats()
        total = int(meta.get("total_count", 0))
        foram_count = int(meta.get("foraminifera_count", 0))
        ostracoda_count = int(meta.get("ostracoda_count", 0))
        diatoms_count = int(meta.get("diatoms_count", 0))
        build_date = meta.get("build_date", "")[:10]
    except Exception:
        total = foram_count = ostracoda_count = diatoms_count = 0
        build_date = ""

    return render_template(
        "index.html",
        total_records=total,
        foram_count=foram_count,
        ostracoda_count=ostracoda_count,
        diatoms_count=diatoms_count,
        build_date=build_date,
        app_version=_read_version(),
    )


# ------------------------------------------------------------------
# Search API
# ------------------------------------------------------------------

@app.route("/api/search")
def api_search():
    q = request.args.get("q", "").strip()
    genus = request.args.get("genus", "").strip()
    author = request.args.get("author", "").strip()
    year_from = _parse_int(request.args.get("year_from"))
    year_to = _parse_int(request.args.get("year_to"))
    database = request.args.get("database", "All")
    pdf_only = request.args.get("pdf_only", "0") == "1"
    fuzzy = request.args.get("fuzzy", "0") == "1"
    page = max(1, _parse_int(request.args.get("page"), 1))
    page_size = min(200, max(10, _parse_int(request.args.get("page_size"), 50)))

    # Validate database filter
    if database not in ("All", "Foraminifera", "Ostracoda", "Diatoms"):
        database = "All"

    from search import search as do_search
    try:
        result = do_search(
            query=q,
            genus=genus,
            author=author,
            year_from=year_from,
            year_to=year_to,
            database=database,
            pdf_only=pdf_only,
            fuzzy=fuzzy,
            page=page,
            page_size=page_size,
        )
        return jsonify(result)
    except FileNotFoundError as e:
        return jsonify({"error": str(e), "results": [], "total": 0}), 503
    except Exception as e:
        app.logger.error("Search error: %s", e, exc_info=True)
        return jsonify({"error": "Search failed", "results": [], "total": 0}), 500


# ------------------------------------------------------------------
# Autocomplete suggest API
# ------------------------------------------------------------------

@app.route("/api/suggest")
def api_suggest():
    q = request.args.get("q", "").strip()
    if len(q) < 2:
        return jsonify([])
    from search import suggest
    try:
        suggestions = suggest(q, limit=12)
        return jsonify(suggestions)
    except Exception:
        return jsonify([])


# ------------------------------------------------------------------
# WoRMS lookup API
# ------------------------------------------------------------------

@app.route("/api/worms/<path:taxon_name>")
def api_worms(taxon_name):
    taxon_name = taxon_name.strip()
    if not taxon_name:
        return jsonify({"error": "Empty taxon name"}), 400

    force_refresh = request.args.get("refresh", "0") == "1"
    database = request.args.get("database", "Foraminifera")

    from worms_integration import lookup, mikrotax_url, mikrotax_links
    try:
        result = lookup(taxon_name, use_cache=(not force_refresh))
        result.pop("_cache_key", None)  # internal field, don't expose
        result["mikrotax_url"]   = mikrotax_url(taxon_name, database)   # backward compat
        result["mikrotax_links"] = mikrotax_links(taxon_name, database)  # full list
        return jsonify(result)
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 503
    except Exception as e:
        app.logger.error("WoRMS error for %r: %s", taxon_name, e, exc_info=True)
        return jsonify({"error": "WoRMS lookup failed", "status": "error"}), 500


# ------------------------------------------------------------------
# Mikrotax data API
# ------------------------------------------------------------------

@app.route("/api/mikrotax/<path:taxon_name>")
def api_mikrotax(taxon_name):
    taxon_name = taxon_name.strip()
    if not taxon_name:
        return jsonify({"error": "Empty taxon name", "modules": []}), 400

    database      = request.args.get("database", "Foraminifera")
    force_refresh = request.args.get("refresh", "0") == "1"

    from worms_integration import fetch_mikrotax_data
    try:
        result = fetch_mikrotax_data(
            taxon_name, database, use_cache=(not force_refresh)
        )
        return jsonify(result)
    except Exception as e:
        app.logger.error("Mikrotax error for %r: %s", taxon_name, e, exc_info=True)
        return jsonify({"error": "Mikrotax lookup failed", "modules": []}), 500


# ------------------------------------------------------------------
# Stats API
# ------------------------------------------------------------------

@app.route("/api/stats")
def api_stats():
    from search import get_stats
    try:
        meta = get_stats()
    except Exception:
        meta = {}
    try:
        from worms_integration import get_cache_stats
        worms = get_cache_stats()
    except Exception:
        worms = {}
    return jsonify({**meta, "worms": worms})


# ------------------------------------------------------------------
# PDF serving
# ------------------------------------------------------------------

@app.route("/pdf/<record_id>/<database>")
def serve_pdf(record_id, database):
    if not re.match(r'^[\w\-]+$', record_id) or not re.match(r'^[A-Za-z]+$', database):
        abort(400)

    from search import get_db
    try:
        conn = get_db()
        row = conn.execute(
            "SELECT pdf_path, taxon_name FROM records "
            "WHERE record_id = ? AND database = ?",
            (record_id, database),
        ).fetchone()
    except Exception:
        abort(404)

    if not row or not row["pdf_path"]:
        abort(404)

    pdf_path_rel = row["pdf_path"]
    taxon_name   = row["taxon_name"]

    # Resolve: try PDF_BASE first, then PROJECT_ROOT as fallback
    pdf_abs = (PDF_BASE / pdf_path_rel).resolve()
    if not pdf_abs.exists():
        pdf_abs = (PROJECT_ROOT / pdf_path_rel).resolve()

    if not pdf_abs.exists():
        # Return a helpful JSON error instead of a bare 404
        return (
            f'<html><body style="font-family:sans-serif;padding:40px">'
            f'<h2>PDF not found</h2>'
            f'<p><em>{taxon_name}</em></p>'
            f'<p>Expected location:<br><code>{PDF_BASE / pdf_path_rel}</code></p>'
            f'<p>To fix this, copy the <strong>downloads/</strong> folder '
            f'into the same directory as the app, or create a '
            f'<strong>pdf_base.txt</strong> file pointing to where your PDFs are stored.</p>'
            f'</body></html>',
            404,
        )

    # Security: path must stay within PDF_BASE or PROJECT_ROOT
    try:
        pdf_abs.relative_to(PDF_BASE)
    except ValueError:
        try:
            pdf_abs.relative_to(PROJECT_ROOT)
        except ValueError:
            abort(403)

    safe_name     = re.sub(r'[^\w\s\-]', '_', taxon_name)[:80]
    download_name = f"{safe_name}_{record_id}.pdf"

    return send_file(
        pdf_abs,
        mimetype="application/pdf",
        as_attachment=False,
        download_name=download_name,
    )


# ------------------------------------------------------------------
# GBIF image serving (locally cached images)
# ------------------------------------------------------------------

@app.route("/worms_images/<path:filename>")
def serve_worms_image(filename):
    """Serve locally-downloaded GBIF specimen images."""
    images_root = (PROJECT_ROOT / "worms_images").resolve()
    try:
        img_path = (images_root / filename).resolve()
        img_path.relative_to(images_root)   # security: no path traversal
    except (ValueError, Exception):
        abort(403)
    if not img_path.exists():
        abort(404)
    return send_file(img_path, as_attachment=False)


# ------------------------------------------------------------------
# Dev runner (use run.py for production startup)
# ------------------------------------------------------------------

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5050, debug=True)
