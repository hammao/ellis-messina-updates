/* Ellis & Messina Offline Search — app.js */

'use strict';

// ------------------------------------------------------------------
// State
// ------------------------------------------------------------------
const state = {
    page: 1,
    pageSize: 50,
    lastResult: null,
    searching: false,
};

// Leaflet map instance (one at a time in the WoRMS panel)
let _leafletMap = null;

// ------------------------------------------------------------------
// DOM refs
// ------------------------------------------------------------------
const $ = id => document.getElementById(id);
const qf = {
    query:    () => $('q').value.trim(),
    genus:    () => $('f-genus').value.trim(),
    author:   () => $('f-author').value.trim(),
    yearFrom: () => $('f-year-from').value.trim(),
    yearTo:   () => $('f-year-to').value.trim(),
    database: () => $('f-database').value,
    pdfOnly:  () => $('f-pdf-only').checked ? '1' : '0',
    fuzzy:    () => $('f-fuzzy').checked ? '1' : '0',
};

// ------------------------------------------------------------------
// Search
// ------------------------------------------------------------------

async function doSearch(page = 1) {
    if (state.searching) return;
    state.searching = true;
    state.page = page;

    setLoading(true);

    const params = new URLSearchParams({
        q:         qf.query(),
        genus:     qf.genus(),
        author:    qf.author(),
        year_from: qf.yearFrom(),
        year_to:   qf.yearTo(),
        database:  qf.database(),
        pdf_only:  qf.pdfOnly(),
        fuzzy:     qf.fuzzy(),
        page:      page,
        page_size: state.pageSize,
    });

    try {
        const resp = await fetch('/api/search?' + params);
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();
        state.lastResult = data;
        renderResults(data);
    } catch (e) {
        showError('Search failed: ' + e.message);
    } finally {
        state.searching = false;
        setLoading(false);
    }
}

function setLoading(on) {
    $('btn-search').disabled = on;
    $('btn-search').textContent = on ? 'Searching…' : 'Search';
}

function showError(msg) {
    $('error-msg').textContent = msg;
    $('error-msg').style.display = 'block';
    setTimeout(() => { $('error-msg').style.display = 'none'; }, 5000);
}

// ------------------------------------------------------------------
// Mikrotax URL helper (mirrors server-side MIKROTAX_MODULES mapping)
// ------------------------------------------------------------------

// Mikrotax modules per database — mirrors server-side MIKROTAX_MODULES
const MIKROTAX_MODULES = {
    Foraminifera: [
        { module: 'pf_cenozoic', short: 'PT', label: 'Planktonic Foraminifera' },
        { module: 'bf_main',     short: 'BF', label: 'Benthic Foraminifera' },
    ],
    Diatoms: [
        { module: 'diatoms',     short: 'DT', label: 'Diatoms' },
    ],
};

const _MT_BASE   = 'https://www.mikrotax.org/system/index.php';
const _MT_SEARCH = 'https://www.mikrotax.org/system/search.php';

/**
 * Extract the clean binomial (Genus species) from a full E&M name.
 * Mirrors server-side _extract_binomial() in worms_integration.py.
 *
 * 'Hantkenina alabamensis Cushman var. compressa'  → 'Hantkenina alabamensis'
 * 'Triloculina trigonula (Lamarck) var. multistriata' → 'Triloculina trigonula'
 * 'Globigerina bulloides d\'Orbigny, 1826'          → 'Globigerina bulloides'
 */
function _mtSearchName(name) {
    let s = name.replace(/\([^)]*\)/g, '');   // remove (author, year)
    s = s.replace(/\b(var|subvar|subsp|ssp|f|forma|nov|sp|aff|cf|sensu)\b.*/i, '');
    s = s.replace(/,.*/, '');                  // remove trailing author cruft
    const words = s.trim().split(/\s+/).filter(Boolean);
    if (words.length >= 2) return words[0] + ' ' + words[1];
    return words[0] || name;
}

function _mikrotaxCell(taxonName, database) {
    const entries = MIKROTAX_MODULES[database];
    if (!entries) return '<span class="no-pdf">—</span>';

    // Use the clean binomial with search.php so complex E&M names
    // (with author, var., subsp.) always resolve correctly on Mikrotax.
    // search.php redirects straight to the taxon page when there is
    // exactly one match, otherwise shows a results list — either works.
    const searchName = _mtSearchName(taxonName);
    return entries.map(e => {
        const url = `${_MT_SEARCH}?tName=${encodeURIComponent(searchName)}&module=${encodeURIComponent(e.module)}`;
        return `<a class="mt-link mt-${e.module}" href="${escHtml(url)}"
                   target="_blank" title="${escHtml(e.label)} — ${escHtml(searchName)}">${e.short}</a>`;
    }).join('');
}

function _mikrotaxLinksHtml(links) {
    // Render the mikrotax_links array returned by /api/worms/ (includes search_url)
    if (!links || links.length === 0) return '';
    return links.map(lk =>
        `<a href="${escHtml(lk.search_url || lk.url)}" target="_blank" rel="noopener"
            class="worms-link" title="${escHtml(lk.label)} — search Mikrotax">
            Mikrotax ${escHtml(lk.short)} ↗</a>`
    ).join(' ');
}

// ------------------------------------------------------------------
// Render results
// ------------------------------------------------------------------

function renderResults(data) {
    $('error-msg').style.display = 'none';

    // Results bar
    const bar = $('results-bar');
    if (data.total === 0) {
        // Auto-lookup on WoRMS when the E&M search finds nothing
        const q = qf.query();
        bar.innerHTML = `
            <span class="results-count" style="color:var(--amber)">
                <strong>Not found</strong> in Ellis &amp; Messina catalogue.
                ${q ? `Automatically searching WoRMS for <em>${escHtml(q)}</em>&hellip;` : ''}
            </span>`;
        if (q) {
            const autoDb = qf.database() !== 'All' ? qf.database() : 'Foraminifera';
            lookupWorms(q, false, autoDb);
        }
        return;
    } else {
        const typeLabel = {
            fts:    'FTS',
            fuzzy:  'Fuzzy',
            like:   'LIKE',
            browse: 'Browse',
        }[data.query_type] || data.query_type;

        const fuzzyWarn = data.query_type === 'fuzzy'
            ? `<span class="fuzzy-warn">~100ms</span>` : '';

        bar.innerHTML = `
            <span class="results-count">
                Found <strong>${data.total.toLocaleString()}</strong> record${data.total !== 1 ? 's' : ''}
                &nbsp;<span class="query-type-badge">${typeLabel}</span>${fuzzyWarn}
                &nbsp;<span style="color:var(--muted);font-size:12px">${data.elapsed_ms}ms</span>
            </span>
            <button class="btn btn-csv" onclick="exportCsv()" title="Download all results as CSV">
                &#x2193; CSV
            </button>
            <div class="pagination">
                <button id="pg-prev" ${data.page <= 1 ? 'disabled' : ''}
                        onclick="doSearch(${data.page - 1})">&#8592; Prev</button>
                <span class="page-info">Page ${data.page} of ${data.pages}</span>
                <button id="pg-next" ${data.page >= data.pages ? 'disabled' : ''}
                        onclick="doSearch(${data.page + 1})">Next &#8594;</button>
            </div>
        `;
    }

    // Table body
    const tbody = $('results-body');
    tbody.innerHTML = '';

    if (data.results.length === 0) {
        tbody.innerHTML = `
            <tr class="state-row">
                <td colspan="9">
                    No records found. Try a broader search or enable Fuzzy matching.
                </td>
            </tr>`;
        return;
    }

    const offset = (data.page - 1) * state.pageSize;
    data.results.forEach((rec, i) => {
        const num = offset + i + 1;
        const tr = document.createElement('tr');

        // PDF cell
        const pdfCell = rec.pdf_url
            ? `<a class="pdf-link" href="${escHtml(rec.pdf_url)}" target="_blank">PDF</a>`
            : `<span class="no-pdf">—</span>`;

        // DB badge
        const dbClass = `db-${escHtml(rec.database)}`;

        // Extinction status badge
        let statusCell;
        if (rec.is_extinct === 1) {
            statusCell = `<span class="status-badge status-extinct">Extinct</span>`;
        } else if (rec.is_extinct === 0) {
            statusCell = `<span class="status-badge status-extant">Extant</span>`;
        } else {
            statusCell = `<span class="status-unknown">?</span>`;
        }

        tr.innerHTML = `
            <td class="col-num">${num}</td>
            <td class="col-taxon" title="${escHtml(rec.taxon_name)}">${escHtml(rec.taxon_name)}</td>
            <td class="col-auth" title="${escHtml(rec.author)}">${escHtml(rec.author)}</td>
            <td class="col-year">${rec.year || '—'}</td>
            <td><span class="db-badge ${dbClass}">${escHtml(rec.database.substring(0,5))}</span></td>
            <td class="col-status">${statusCell}</td>
            <td class="col-pdf">${pdfCell}</td>
            <td class="col-worms">
                <button class="worms-btn" data-name="${escHtml(rec.taxon_name)}" data-database="${escHtml(rec.database)}">WoRMS</button>
            </td>
            <td class="col-mikrotax">${_mikrotaxCell(rec.taxon_name, rec.database)}</td>
        `;
        tbody.appendChild(tr);
    });
}

// ------------------------------------------------------------------
// WoRMS lookup
// ------------------------------------------------------------------

async function lookupWorms(name, forceRefresh = false, database = '') {
    const panel = $('worms-panel');
    const content = $('worms-content');
    panel.classList.add('visible');
    panel.dataset.database = database;
    $('worms-queried').textContent = name;
    content.innerHTML = `<span class="worms-loading">Looking up <em>${escHtml(name)}</em> in WoRMS…</span>`;

    let params = [];
    if (forceRefresh) params.push('refresh=1');
    if (database)    params.push('database=' + encodeURIComponent(database));
    const url = '/api/worms/' + encodeURIComponent(name) + (params.length ? '?' + params.join('&') : '');
    try {
        const resp = await fetch(url);
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();
        renderWormsPanel(data);
        // Append Mikrotax section asynchronously after WoRMS panel renders
        const mtDb = database && database !== 'All' ? database : 'Foraminifera';
        if (mtDb !== 'Ostracoda') {
            _appendMikrotaxAsync(content, name, mtDb, forceRefresh);
        }
    } catch (e) {
        content.innerHTML = `<span class="worms-error">WoRMS lookup failed: ${escHtml(e.message)}</span>`;
    }
}

function renderWormsPanel(d) {
    const content = $('worms-content');

    if (!d.found || d.status === 'not_found') {
        const pbdbHtml = _renderPbdb(d.pbdb);
        content.innerHTML = `
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
                <span class="status-badge status-not_found">Not in WoRMS API</span>
                <span style="color:var(--muted);font-size:12px">
                    WoRMS REST API excludes extinct taxa from name search.
                    ${!(d.pbdb && d.pbdb.found) ? `Try <a href="https://paleobiodb.org/navigator/#/taxon/${encodeURIComponent(d.taxon_name)}" target="_blank" style="color:var(--blue)">Paleobiology Database ↗</a> for fossil records.` : ''}
                </span>
                <a href="https://www.marinespecies.org/aphia.php?p=search&adv=1&tName=${encodeURIComponent(d.taxon_name)}"
                   target="_blank"
                   style="color:var(--blue);font-size:12px;white-space:nowrap">
                    Search WoRMS website ↗
                </a>
                ${_mikrotaxLinksHtml(d.mikrotax_links)}
                <button class="btn btn-sm" id="worms-refresh-btn" style="margin-left:auto">Refresh</button>
            </div>
            ${pbdbHtml}`;
        return;
    }

    if (d.status === 'error') {
        content.innerHTML = `
            <span class="worms-error">Error: ${escHtml(d.error || 'WoRMS lookup failed')}</span>
            <button class="btn btn-sm" id="worms-refresh-btn" style="margin-left:8px">Retry</button>`;
        return;
    }

    const statusClass = `status-${d.status}`;
    const statusLabel = d.status.charAt(0).toUpperCase() + d.status.slice(1);

    // ── Overview row ──────────────────────────────────────────────
    const queried = $('worms-queried').textContent.toLowerCase();
    const validIsDiff = d.valid_name && d.valid_name.toLowerCase() !== queried;
    const validHtml = validIsDiff
        ? `<div class="worms-valid">
               &#8594; Accepted name: <em>${escHtml(d.valid_name)}</em>
               <span class="authority">${escHtml(d.valid_authority || '')}</span>
           </div>` : '';

    const unacceptHtml = d.unaccept_reason
        ? `<div style="font-size:11px;color:var(--muted);margin-top:3px">
               Reason: ${escHtml(d.unaccept_reason)}
           </div>` : '';

    // Habitat flags
    const habitats = [
        [d.is_marine,     'Marine',      '#0c6070', '#e0f2fe'],
        [d.is_brackish,   'Brackish',    '#166534', '#dcfce7'],
        [d.is_freshwater, 'Freshwater',  '#1e40af', '#dbeafe'],
        [d.is_terrestrial,'Terrestrial', '#713f12', '#fef9c3'],
    ].filter(([val]) => val === true)
     .map(([, label, fg, bg]) =>
        `<span class="habitat-tag" style="background:${bg};color:${fg}">${label}</span>`)
     .join('');

    const extinctHtml = d.is_extinct
        ? `<span class="habitat-tag" style="background:#fee2e2;color:#991b1b">Extinct</span>` : '';

    const rankHtml = d.rank
        ? `<span style="font-size:11px;color:var(--muted);margin-left:6px">Rank: ${escHtml(d.rank)}</span>` : '';

    const modHtml = d.modified
        ? `<span style="font-size:11px;color:var(--muted)">WoRMS updated: ${escHtml(d.modified)}</span>` : '';

    // ── Full classification (priority — expanded by default) ───────
    const fullClassHtml = _renderClassification(d.full_classification, d.classification);

    // ── Synonyms section ──────────────────────────────────────────
    const synHtml = _renderSynonyms(d.synonyms);

    // ── Sources / references ──────────────────────────────────────
    const srcHtml = _renderSources(d.sources);

    // ── Distribution ──────────────────────────────────────────────
    const distHtml = _renderDistribution(d.distribution);

    // ── Identifiers ───────────────────────────────────────────────
    const idHtml = _renderIdentifiers(d);

    // ── Images (GBIF) ─────────────────────────────────────────────
    const imgHtml = _renderImages(d.media);

    // ── Footer ────────────────────────────────────────────────────
    const linkHtml = d.worms_url
        ? `<a class="worms-link" href="${escHtml(d.worms_url)}" target="_blank">View in WoRMS ↗</a>` : '';
    const mikrotaxHtml = _mikrotaxLinksHtml(d.mikrotax_links);
    const cacheHtml = d.from_cache
        ? `<span class="worms-cached">&#x1f4be; Cached · ${(d.fetched_at||'').substring(0,10)}</span>` : '';

    content.innerHTML = `
        <div class="worms-overview">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <span class="status-badge ${statusClass}">${statusLabel}</span>
                ${rankHtml}
                ${habitats}${extinctHtml}
            </div>
            ${validHtml}${unacceptHtml}
        </div>

        ${fullClassHtml}
        ${synHtml}
        ${srcHtml}
        ${distHtml}
        ${idHtml}
        ${imgHtml}
        ${_renderPbdb(d.pbdb)}

        <div class="worms-footer">
            ${linkHtml}
            ${mikrotaxHtml}
            ${modHtml}
            ${cacheHtml}
            <button class="btn btn-sm" id="worms-refresh-btn">Refresh</button>
        </div>
    `;

    // Init Leaflet map after HTML is in DOM (requestAnimationFrame ensures layout)
    if (_pendingMapPoints) {
        const pts = _pendingMapPoints;
        _pendingMapPoints = null;
        requestAnimationFrame(() => _initDistMap(pts));
    }
}

// ── Section renderers ─────────────────────────────────────────────

function _wSection(id, title, count, bodyHtml, openByDefault = false) {
    const countBadge = count !== null
        ? `<span class="wsec-count">${count}</span>` : '';
    const openClass = openByDefault ? ' open' : '';
    return `
        <div class="worms-section${openClass}" id="wsec-${id}">
            <button class="wsec-header" data-sec="${id}">
                <span class="wsec-arrow">▶</span>
                <span class="wsec-title">${title}</span>
                ${countBadge}
            </button>
            <div class="wsec-body">${bodyHtml}</div>
        </div>`;
}

function _renderClassification(full, brief) {
    let rows;
    if (full && full.length > 0) {
        rows = full.map(item =>
            `<tr>
                <td class="cl-rank">${escHtml(item.rank)}</td>
                <td class="cl-name">${escHtml(item.name)}</td>
             </tr>`
        ).join('');
    } else {
        const c = brief || {};
        rows = [['Kingdom',c.kingdom],['Phylum',c.phylum],['Class',c.class],
                ['Order',c.order],['Family',c.family],['Genus',c.genus]]
            .filter(([,v]) => v)
            .map(([r,n]) => `<tr><td class="cl-rank">${r}</td><td class="cl-name">${escHtml(n)}</td></tr>`)
            .join('');
    }
    const body = `<table class="cl-table">${rows}</table>`;
    return _wSection('class', 'Full Classification', full ? full.length : null, body, true);
}

function _renderSynonyms(synonyms) {
    if (!synonyms || synonyms.length === 0) {
        return _wSection('syn', 'Synonyms', 0,
            `<span class="wsec-empty">No synonyms recorded in WoRMS</span>`);
    }
    const items = synonyms.map(s =>
        `<li><em>${escHtml(s.name)}</em>
             <span class="syn-auth">${escHtml(s.authority||'')}</span>
             ${s.status ? `<span class="syn-status">(${escHtml(s.status)})</span>` : ''}
         </li>`
    ).join('');
    return _wSection('syn', 'Synonyms', synonyms.length,
        `<ul class="wsec-list">${items}</ul>`);
}

function _renderSources(sources) {
    if (!sources || sources.length === 0) {
        return _wSection('src', 'References', 0,
            `<span class="wsec-empty">No references recorded</span>`);
    }
    const items = sources.map(s => {
        const isOrig = (s.use || '').toLowerCase().includes('original');
        const tagClass = isOrig ? 'src-tag src-orig' : 'src-tag';
        const tagText  = s.use ? escHtml(s.use) : '';
        const doi = s.doi
            ? `<a class="src-doi" href="https://doi.org/${escHtml(s.doi)}" target="_blank">DOI ↗</a>` : '';
        const page = s.page ? `<span class="src-page">p. ${escHtml(s.page)}</span>` : '';
        return `<li class="src-item">
                    <span class="${tagClass}">${tagText}</span>
                    <span class="src-ref">${escHtml(s.reference||'')}</span>
                    ${page}${doi}
                </li>`;
    }).join('');
    return _wSection('src', 'References', sources.length,
        `<ul class="wsec-list src-list">${items}</ul>`, true);
}

function _renderDistribution(dist) {
    _pendingMapPoints = null;   // reset from any prior lookup

    if (!dist || dist.length === 0) {
        return _wSection('dist', 'Distribution', 0,
            `<span class="wsec-empty">No distribution records in WoRMS</span>`);
    }

    const withCoords = dist.filter(d => d.lat != null && d.lon != null);

    // Text list (always shown below the map)
    const listItems = dist.map(d =>
        `<li class="dist-item">
             <span class="dist-loc">${escHtml(d.locality)}</span>
             ${d.higher_geography
                ? `<span class="dist-region">${escHtml(d.higher_geography)}</span>`
                : ''}
         </li>`
    ).join('');
    const listHtml = `<ul class="dist-grid">${listItems}</ul>`;

    if (withCoords.length === 0) {
        // No coordinates yet — plain list, section collapsed
        return _wSection('dist', 'Distribution', dist.length, listHtml);
    }

    // Map + collapsible list
    const bodyHtml = `
        <div id="dist-map-canvas" class="dist-map"></div>
        <details class="dist-list-toggle">
            <summary class="dist-list-summary">Locality list (${dist.length})</summary>
            ${listHtml}
        </details>`;

    // Schedule Leaflet init after this HTML lands in the DOM
    _pendingMapPoints = withCoords;

    // Open by default when we have a map
    return _wSection('dist', 'Distribution', dist.length, bodyHtml, true);
}

let _pendingMapPoints = null;

// Fix Leaflet's default icon path when JS is served from /static/
function _fixLeafletIcons() {
    if (typeof L === 'undefined') return;
    delete L.Icon.Default.prototype._getIconUrl;
    L.Icon.Default.mergeOptions({
        iconUrl:       '/static/leaflet/images/marker-icon.png',
        iconRetinaUrl: '/static/leaflet/images/marker-icon-2x.png',
        shadowUrl:     '/static/leaflet/images/marker-shadow.png',
    });
}

function _initDistMap(points) {
    if (typeof L === 'undefined') {
        console.error('Leaflet not loaded — distribution map unavailable');
        return;
    }
    _fixLeafletIcons();

    const container = document.getElementById('dist-map-canvas');
    if (!container) return;

    // Destroy stale instance to avoid "already initialized" error on re-lookup
    if (_leafletMap) {
        _leafletMap.remove();
        _leafletMap = null;
    }

    _leafletMap = L.map(container, { scrollWheelZoom: false });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 10,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a>',
    }).addTo(_leafletMap);

    const group = L.featureGroup();
    points.forEach(d => {
        const m = L.circleMarker([d.lat, d.lon], {
            radius: 7,
            color:       '#0369a1',
            fillColor:   '#38bdf8',
            fillOpacity: 0.85,
            weight:      1.5,
        });
        const popup = `<strong>${escHtml(d.locality)}</strong>`
            + (d.higher_geography
                ? `<br><small style="color:#64748b">${escHtml(d.higher_geography)}</small>`
                : '');
        m.bindTooltip(escHtml(d.locality), { direction: 'top', offset: [0, -4] });
        m.bindPopup(popup);
        group.addLayer(m);
    });
    group.addTo(_leafletMap);

    if (points.length > 0) {
        _leafletMap.fitBounds(group.getBounds().pad(0.25));
    }

    // Ensure tiles redraw after the panel fully paints
    setTimeout(() => { if (_leafletMap) _leafletMap.invalidateSize(); }, 100);
}

function _renderIdentifiers(d) {
    const rows = [];
    if (d.aphia_id)  rows.push(['AphiaID', `<strong>${d.aphia_id}</strong>`]);
    if (d.lsid)      rows.push(['LSID',    `<code class="lsid">${escHtml(d.lsid)}</code>`]);
    if (d.citation)  rows.push(['Cite as', `<span class="citation-text">${escHtml(d.citation)}</span>`]);

    if (rows.length === 0) return '';

    const tableRows = rows.map(([k,v]) =>
        `<tr><td class="id-key">${k}</td><td class="id-val">${v}</td></tr>`
    ).join('');
    return _wSection('ids', 'Identifiers &amp; Citation', null,
        `<table class="id-table">${tableRows}</table>`);
}

function _renderImages(media) {
    if (!media || media.length === 0) return '';

    const wormsCount = media.filter(m => m.source === 'worms').length;
    const gbifCount  = media.filter(m => m.source !== 'worms').length;

    const items = media.map(m => {
        const isWorms = m.source === 'worms';

        // Prefer local cached path; for WoRMS images use local_path, fall back to thumb_url then url
        let src;
        if (m.local_path) {
            src = `/worms_images/${m.local_path.replace(/^worms_images\//, '')}`;
        } else if (isWorms && m.thumb_url) {
            src = m.thumb_url;
        } else {
            src = m.url;
        }

        const alt     = escHtml(m.title || 'Specimen image');
        const creator = m.creator ? `<span class="img-creator">\u00a9 ${escHtml(m.creator)}</span>` : '';
        const licHref = m.license || '#';
        const licText = m.license && m.license.includes('creativecommons')
            ? 'CC-BY' : (m.license ? 'License' : '');
        const licHtml = licText
            ? `<a class="img-lic" href="${escHtml(licHref)}" target="_blank" rel="noopener">${licText}</a>` : '';

        let badge = '';
        if (isWorms) {
            badge = `<span class="img-source-badge img-source-worms">WoRMS</span>`;
        } else if (m.type === 'illustration') {
            badge = `<span class="img-type-badge">Illustration</span>`;
        }

        return `
            <figure class="img-fig">
                <a href="${escHtml(m.url)}" target="_blank" rel="noopener" title="Open full image">
                    <img class="gbif-img" src="${escHtml(src)}" alt="${alt}"
                         loading="lazy"
                         onerror="this.closest('figure').style.display='none'">
                </a>
                <figcaption class="img-cap">
                    ${badge}${creator}${licHtml}
                </figcaption>
            </figure>`;
    }).join('');

    const sourceParts = [];
    if (wormsCount > 0) sourceParts.push(`<a href="https://www.marinespecies.org" target="_blank" rel="noopener">WoRMS</a>`);
    if (gbifCount  > 0) sourceParts.push(`<a href="https://www.gbif.org" target="_blank" rel="noopener">GBIF</a>`);
    const note = `<p class="img-source-note">Images via ${sourceParts.join(' &amp; ')} · click to open full resolution</p>`;

    const sectionTitle = wormsCount > 0 && gbifCount > 0
        ? `Images (WoRMS + GBIF)`
        : wormsCount > 0 ? `Images (WoRMS)` : `Images (GBIF)`;

    return _wSection('imgs', sectionTitle, media.length,
        `<div class="img-gallery">${items}</div>${note}`, true);
}

// ── Section toggle (event delegation in DOMContentLoaded) ────────
function toggleWSection(secId) {
    const el = document.getElementById(`wsec-${secId}`);
    if (!el) return;
    el.classList.toggle('open');
    // When the dist section opens, Leaflet must recalculate the container size
    // (it was display:none during init, so tile layout was deferred)
    if (secId === 'dist' && el.classList.contains('open') && _leafletMap) {
        requestAnimationFrame(() => _leafletMap.invalidateSize());
    }
}

// ------------------------------------------------------------------
// PBDB panel renderer (used in both found and not-found WoRMS panels)
// ------------------------------------------------------------------

function _renderPbdb(pbdb) {
    if (!pbdb || !pbdb.found) return '';
    const stRange = (pbdb.first_interval && pbdb.last_interval)
        ? `${escHtml(pbdb.first_interval)} – ${escHtml(pbdb.last_interval)}`
        : escHtml(pbdb.first_interval || pbdb.last_interval || '');
    const maBound = (pbdb.first_ma_early != null && pbdb.last_ma_late != null)
        ? ` (${pbdb.first_ma_early}–${pbdb.last_ma_late} Ma)` : '';
    const synNote = (pbdb.status === 'synonym' && pbdb.accepted_name)
        ? `<div style="margin-top:4px;color:var(--amber);font-size:12px">
               PBDB treats this as a synonym of <em>${escHtml(pbdb.accepted_name)}</em>
           </div>` : '';
    const classLine = [pbdb.phylum, pbdb.order, pbdb.family].filter(Boolean).join(' › ');
    return `
    <div class="pbdb-panel" style="margin-top:12px;border-top:1px solid var(--border);padding-top:10px">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px">
            <span class="status-badge" style="background:#5a3e28;color:#e8c49a">Fossil record · PBDB</span>
            <strong style="font-size:13px">${escHtml(pbdb.name)}</strong>
            <a href="${escHtml(pbdb.pbdb_url)}" target="_blank"
               style="color:var(--blue);font-size:12px;margin-left:auto">
                Paleobiology Database ↗
            </a>
        </div>
        ${classLine ? `<div style="font-size:12px;color:var(--muted);margin-bottom:4px">${escHtml(classLine)}</div>` : ''}
        ${synNote}
        <div style="display:grid;grid-template-columns:auto 1fr;gap:2px 10px;font-size:12px;margin-top:6px">
            ${stRange ? `<span style="color:var(--muted)">Strat. range</span><span>${stRange}${escHtml(maBound)}</span>` : ''}
            ${pbdb.occurrences ? `<span style="color:var(--muted)">Occurrences</span><span>${pbdb.occurrences} fossil records in PBDB</span>` : ''}
        </div>
        ${pbdb.reference ? `<div style="margin-top:6px;font-size:11px;color:var(--muted);font-style:italic">${escHtml(pbdb.reference)}</div>` : ''}
    </div>`;
}

// ------------------------------------------------------------------
// Autocomplete
// ------------------------------------------------------------------

let suggestTimer = null;
function onQueryInput() {
    clearTimeout(suggestTimer);

    // Always clear previous results and WoRMS panel the moment the user starts typing
    $('results-bar').innerHTML = '';
    $('results-body').innerHTML = `<tr class="state-row"><td colspan="9">Press Search or Enter to search.</td></tr>`;
    closeWorms();

    const q = $('q').value.trim();
    if (q.length < 2) return;
    suggestTimer = setTimeout(() => fetchSuggestions(q), 250);
}

async function fetchSuggestions(q) {
    try {
        const resp = await fetch('/api/suggest?q=' + encodeURIComponent(q));
        const names = await resp.json();
        const dl = $('suggestions');
        dl.innerHTML = '';
        names.forEach(n => {
            const opt = document.createElement('option');
            opt.value = n;
            dl.appendChild(opt);
        });
    } catch (_) {}
}

// ------------------------------------------------------------------
// Clear / reset
// ------------------------------------------------------------------

function clearSearch() {
    $('q').value = '';
    $('f-genus').value = '';
    $('f-author').value = '';
    $('f-year-from').value = '';
    $('f-year-to').value = '';
    $('f-database').value = 'All';
    $('f-pdf-only').checked = false;
    $('f-fuzzy').checked = false;
    $('results-bar').innerHTML = '';
    $('results-body').innerHTML = `
        <tr class="state-row">
            <td colspan="9">Enter a name above and press Search.</td>
        </tr>`;
    closeWorms();
}

function closeWorms() {
    if (_leafletMap) {
        _leafletMap.remove();
        _leafletMap = null;
    }
    $('worms-panel').classList.remove('visible');
}

// ------------------------------------------------------------------
// Keyboard shortcut: Enter to search
// ------------------------------------------------------------------

function onQueryKeydown(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        doSearch(1);
    }
}

// ------------------------------------------------------------------
// Mikrotax panel (async, appended after WoRMS renders)
// ------------------------------------------------------------------

async function _appendMikrotaxAsync(contentEl, name, database, forceRefresh) {
    // Inject a collapsible placeholder at the bottom of worms-content
    const placeholder = document.createElement('div');
    placeholder.id = 'mikrotax-inject';
    placeholder.innerHTML = _wSection('mikrotax-loading', 'Mikrotax Data', null,
        '<span class="worms-loading">Loading Mikrotax data…</span>', false);
    contentEl.appendChild(placeholder);

    const params = ['database=' + encodeURIComponent(database)];
    if (forceRefresh) params.push('refresh=1');
    const url = '/api/mikrotax/' + encodeURIComponent(name) + '?' + params.join('&');

    try {
        const resp = await fetch(url);
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();
        const html = _renderMikrotaxSections(data);
        placeholder.innerHTML = html || '';   // empty = remove placeholder silently
    } catch (e) {
        placeholder.innerHTML = '';           // hide on error — WoRMS data is still shown
    }
}

function _renderMikrotaxSections(data) {
    const modules = data.modules || [];
    if (modules.length === 0) return '';

    return modules.map(mod => {
        const imgHtml   = _renderMikrotaxImages(mod.images || []);
        const stratHtml = _renderMikrotaxStrat(mod);
        const classHtml = mod.classification && mod.classification.length > 1
            ? `<div class="mt-class">${mod.classification.slice(1).map(escHtml).join(' › ')}</div>`
            : '';
        const matchNote = (mod.matched_query && mod.matched_query !== data.taxon_name)
            ? `<div class="mt-match-note">Matched as <em>${escHtml(mod.matched_query)}</em></div>` : '';
        const cacheNote = mod.from_cache
            ? `<span class="worms-cached">&#x1f4be; Cached</span>` : '';
        const bodyHtml = `
            ${matchNote}
            ${imgHtml}
            ${stratHtml}
            ${classHtml}
            <div class="mt-footer">
                <a class="worms-link" href="${escHtml(mod.page_url)}"
                   target="_blank" rel="noopener">
                   View in Mikrotax ${escHtml(mod.short)} ↗
                </a>
                ${cacheNote}
            </div>`;

        const imgCount = (mod.images || []).length;
        const title    = `Mikrotax — ${escHtml(mod.label)}`;
        return _wSection(`mt-${mod.module}`, title, imgCount || null, bodyHtml, true);
    }).join('');
}

function _renderMikrotaxStrat(mod) {
    const rows = [];
    if (mod.strat_notes) rows.push(['Range notes', escHtml(mod.strat_notes)]);
    if (mod.last_occ)   rows.push(['LO (top)',    escHtml(mod.last_occ)]);
    if (mod.first_occ)  rows.push(['FO (base)',   escHtml(mod.first_occ)]);
    if (mod.depth_range) rows.push(['Depth',      escHtml(mod.depth_range)]);
    if (rows.length === 0) return '';

    const trs = rows.map(([k, v]) =>
        `<tr><td class="mt-strat-key">${k}</td><td class="mt-strat-val">${v}</td></tr>`
    ).join('');
    return `<table class="mt-strat-table">${trs}</table>`;
}

function _renderMikrotaxImages(images) {
    if (!images || images.length === 0)
        return '<span class="wsec-empty">No images in Mikrotax for this taxon</span>';

    const items = images.map(img => {
        const src  = escHtml(img.thumb_url);
        const href = escHtml(img.full_url);
        const alt  = escHtml(img.caption || img.source || 'Mikrotax image');
        const src_ = escHtml(img.source || '');
        const age  = img.geo_age ? `<span class="mt-img-age">${escHtml(img.geo_age)}</span>` : '';
        return `
            <figure class="img-fig">
                <a href="${href}" target="_blank" rel="noopener" title="Open full image">
                    <img class="gbif-img" src="${src}" alt="${alt}"
                         loading="lazy"
                         onerror="this.closest('figure').style.display='none'">
                </a>
                <figcaption class="img-cap">
                    <span class="img-source-badge img-source-worms">MT</span>
                    ${src_ ? `<span class="mt-img-src">${src_}</span>` : ''}
                    ${age}
                </figcaption>
            </figure>`;
    }).join('');

    return `<div class="img-gallery">${items}</div>`;
}

// ------------------------------------------------------------------
// CSV export
// ------------------------------------------------------------------

function exportCsv() {
    const data = state.lastResult;
    if (!data || !data.results || data.results.length === 0) return;

    // Fetch ALL results for this query (re-use same params, page_size=all)
    const params = new URLSearchParams({
        q:         qf.query(),
        genus:     qf.genus(),
        author:    qf.author(),
        year_from: qf.yearFrom(),
        year_to:   qf.yearTo(),
        database:  qf.database(),
        pdf_only:  qf.pdfOnly(),
        fuzzy:     qf.fuzzy(),
        page:      1,
        page_size: Math.min(data.total, 5000),   // cap at 5000 rows
    });

    fetch('/api/search?' + params)
        .then(r => r.json())
        .then(full => {
            const cols = ['#','taxon_name','author','year','database','status','pdf_url'];
            const header = cols.join(',');
            const rows = full.results.map((rec, i) => [
                i + 1,
                _csvCell(rec.taxon_name),
                _csvCell(rec.author),
                rec.year || '',
                _csvCell(rec.database),
                rec.is_extinct === 1 ? 'Extinct' : rec.is_extinct === 0 ? 'Extant' : '',
                _csvCell(rec.pdf_url || ''),
            ].join(','));

            const blob = new Blob([header + '\n' + rows.join('\n')],
                                  {type: 'text/csv;charset=utf-8;'});
            const url  = URL.createObjectURL(blob);
            const a    = document.createElement('a');
            a.href     = url;
            a.download = `ellis_messina_${Date.now()}.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        })
        .catch(() => showError('CSV export failed.'));
}

function _csvCell(val) {
    const s = String(val == null ? '' : val);
    return s.includes(',') || s.includes('"') || s.includes('\n')
        ? '"' + s.replace(/"/g, '""') + '"'
        : s;
}

// ------------------------------------------------------------------
// Footer stats
// ------------------------------------------------------------------

async function loadFooterStats() {
    try {
        const r = await fetch('/api/stats');
        const d = await r.json();
        const wc = d.worms || {};
        const el = $('footer-stats');
        if (!el) return;
        el.innerHTML =
            `<strong>${(d.total_count||0).toLocaleString()}</strong> records`
            + ` &nbsp;·&nbsp; WoRMS cache: <strong>${wc.total_cached||0}</strong> taxa`
            + ` (${wc.found||0} found, ${wc.not_found||0} not found)`
            + (d.build_date ? ` &nbsp;·&nbsp; DB built ${String(d.build_date).substring(0,10)}` : '');
    } catch (_) {}
}

// ------------------------------------------------------------------
// Utils
// ------------------------------------------------------------------

function escHtml(str) {
    if (str == null) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// ------------------------------------------------------------------
// Init
// ------------------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
    $('q').focus();

    // Load footer stats on page load
    loadFooterStats();

    // Escape key closes WoRMS panel
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') closeWorms();
    });

    // Event delegation for all dynamic buttons
    document.addEventListener('click', e => {
        // WoRMS lookup button in results table
        if (e.target.classList.contains('worms-btn')) {
            lookupWorms(e.target.dataset.name, false, e.target.dataset.database || '');
        }
        // Refresh / Retry button inside the WoRMS panel
        if (e.target.id === 'worms-refresh-btn') {
            const name = $('worms-queried').textContent;
            const db = $('worms-panel').dataset.database || '';
            if (name) lookupWorms(name, true, db);
        }
        // Collapsible section headers inside the WoRMS panel
        const hdr = e.target.closest('.wsec-header');
        if (hdr) {
            const sec = hdr.dataset.sec;
            if (sec) toggleWSection(sec);
        }
    });
});
